

<?php $__env->startSection('content'); ?>



<div class="row">
    <div class="col-md-12">
        <h3 class="mb-3">
             Ringkasan Stok Produk 
            <?php echo e(request('warehouse_id') ? 'di ' . ($warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang') : 'Global'); ?>

        </h3>

        
        <form action="<?php echo e(route('stocks.index')); ?>" method="GET" class="mb-4">
            <select name="warehouse_id" class="form-select" onchange="this.form.submit()">
                <option value="">-- Tampilkan Total Stok Global --</option>
                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($w->id); ?>" <?php echo e(request('warehouse_id') == $w->id ? 'selected' : ''); ?>>
                        <?php echo e($w->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>

        
        
<?php if(isset($stocks) && $stocks->isNotEmpty()): ?>

    
    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-dark text-white">
    <h4 class="mb-0">
     Kategori: <?php echo e($category ?? '-'); ?>

    <span class="text-warning">
        (<?php echo e(request('warehouse_id') 
            ? ($warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang Tidak Diketahui') 
            : 'Global'); ?>)
    </span>
</h4>

        <?php if(request('warehouse_id')): ?>
            
            (<?php echo e($warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang Tidak Diketahui'); ?>)
        <?php else: ?>
            (Global)
        <?php endif; ?>
    </h4>
</div>


            <div class="card-body p-0">
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-light">
    <tr>
        <th>Produk</th>
        <th>Kategori</th>
        <th><?php echo e(request('warehouse_id') ? 'Jumlah di Gudang' : 'Total Stok Global'); ?></th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->category->name ?? '-'); ?></td> 
            <td>
                <?php if(request('warehouse_id')): ?>
                    <?php echo e($p->pivot->quantity ?? 0); ?>

                <?php else: ?>
                    <?php echo e($p->total_stock ?? 0); ?>

                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

                </table>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php elseif(request('warehouse_id') && $stocks->isEmpty()): ?>
    <div class="alert alert-info">
        Gudang yang dipilih saat ini tidak memiliki stok produk.
    </div>


<?php else: ?>
    <div class="alert alert-warning">
        Tidak ditemukan data stok produk.
    </div>
<?php endif; ?>

<a href="<?php echo e(route('stocks.transfer')); ?>" class="btn btn-success mt-3">Transfer Stok</a>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/stocks/index.blade.php ENDPATH**/ ?>