

<?php $__env->startSection('content'); ?>
<h2>Tambah Produk</h2>

<form action="<?php echo e(route('products.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="mb-3">
    <label>Nama Produk</label>
    <input type="text" name="name" class="form-control" required>
</div>
<div class="mb-3">
    <label>Kategori</label>
<select name="category_id" class="form-select">
    <option value="">-- Pilih Kategori --</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

</div>
<div class="mb-3">
    <label>Harga</label>
    <input type="number" step="0.01" name="price" class="form-control" required>
</div>
<div class="mb-3">
    <label>Deskripsi</label>
    <textarea name="description" class="form-control"></textarea>
</div>
<div class="row">
    <div class="col-md-6 mb-3">
        <label>Berat (kg)</label>
        <input type="number" step="0.01" name="weight" class="form-control" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Ukuran</label>
        <input type="text" name="size" class="form-control">
    </div>
</div>
<button class="btn btn-primary">Simpan</button>
<a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/products/create.blade.php ENDPATH**/ ?>