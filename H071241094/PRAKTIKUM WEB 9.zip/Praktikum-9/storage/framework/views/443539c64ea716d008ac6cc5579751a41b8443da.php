

<?php $__env->startSection('content'); ?>
<h2>Transfer Stok</h2>

<form action="<?php echo e(route('stocks.transfer')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label>Gudang</label>
        <select name="warehouse_id" class="form-select" required>
            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($w->id); ?>"><?php echo e($w->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Produk</label>
        <select name="product_id" class="form-select" required>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Perubahan Jumlah (+/-)</label>
        <input type="number" name="quantity" class="form-control" placeholder="contoh: +10 atau -5" required>
    </div>

<div class="mb-3">
    <a href="<?php echo e(route('stocks.index')); ?>" class="btn btn-secondary me-2">Kembali</a>
    <button type="submit" class="btn btn-primary">Kirim</button>
</div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/stocks/transfer.blade.php ENDPATH**/ ?>