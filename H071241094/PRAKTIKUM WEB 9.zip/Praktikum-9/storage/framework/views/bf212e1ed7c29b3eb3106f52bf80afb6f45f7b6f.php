

<?php $__env->startSection('content'); ?>
<h2>Edit Kategori</h2>
<form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST">
    <?php echo csrf_field(); ?> 
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label>Nama Kategori</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($category->name); ?>" required>
    </div>
    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="description" class="form-control"><?php echo e($category->description); ?></textarea>
    </div>
    <div class="mb-3">
    <button type="submit" class="btn btn-primary me-2">Perbarui</button>
    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning me-2">Edit</a>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Kembali</a>
</div>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/categories/edit.blade.php ENDPATH**/ ?>