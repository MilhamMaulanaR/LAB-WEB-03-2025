

<?php $__env->startSection('content'); ?>
<h2>Detail Produk</h2>

<p><strong>Nama Produk:</strong> <?php echo e($product->name); ?></p>
<p><strong>Kategori:</strong> <?php echo e($product->category?->name ?? '-'); ?></p>
<p><strong>Harga:</strong> Rp <?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
<p><strong>Deskripsi:</strong> <?php echo e($product->detail->description ?? '-'); ?></p>
<p><strong>Berat:</strong> <?php echo e($product->detail->weight ?? '-'); ?> kg</p>
<p><strong>Ukuran:</strong> <?php echo e($product->detail->size ?? '-'); ?></p>


<p><strong>Dibuat pada:</strong> <?php echo e($product->created_at ? $product->created_at->format('d M Y H:i') : '-'); ?></p>
<p><strong>Terakhir diperbarui:</strong> <?php echo e($product->updated_at ? $product->updated_at->format('d M Y H:i') : '-'); ?></p>

<a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/products/show.blade.php ENDPATH**/ ?>