

<?php $__env->startSection('content'); ?>
<h2>Daftar Gudang</h2>
<a href="<?php echo e(route('warehouses.create')); ?>" class="btn btn-success mb-3">+ Tambah Gudang</a>

<table class="table table-bordered">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Gudang</th>
            <th>Lokasi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($wh->id); ?></td>
            <td><?php echo e($wh->name); ?></td>
            <td><?php echo e($wh->location); ?></td>
            <td>
    <a href="<?php echo e(route('warehouses.show', $wh->id)); ?>" class="btn btn-info btn-sm">Detail</a>
    <a href="<?php echo e(route('warehouses.edit', $wh->id)); ?>" class="btn btn-warning btn-sm">Ubah</a>
    <form action="<?php echo e(route('warehouses.destroy', $wh->id)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus gudang ini?')">Hapus</button>
    </form>
</td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="text-center text-muted">Belum ada data gudang.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/warehouses/index.blade.php ENDPATH**/ ?>