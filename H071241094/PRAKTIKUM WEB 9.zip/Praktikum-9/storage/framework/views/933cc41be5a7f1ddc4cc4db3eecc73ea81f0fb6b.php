

<?php $__env->startSection('content'); ?>
<h2>Daftar Produk</h2>
<a href="<?php echo e(route('products.create')); ?>" class="btn btn-success mb-3">+ Tambah Produk</a>

<table class="table table-bordered">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->id); ?></td>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->category?->name ?? '-'); ?></td>
            <td>Rp <?php echo e(number_format($p->price, 2, ',', '.')); ?></td>
            <td>
                <a href="<?php echo e(route('products.show', $p->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                <a href="<?php echo e(route('products.edit', $p->id)); ?>" class="btn btn-warning btn-sm">Ubah</a>
                <form action="<?php echo e(route('products.destroy', $p->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center text-muted">Belum ada data produk.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/products/index.blade.php ENDPATH**/ ?>