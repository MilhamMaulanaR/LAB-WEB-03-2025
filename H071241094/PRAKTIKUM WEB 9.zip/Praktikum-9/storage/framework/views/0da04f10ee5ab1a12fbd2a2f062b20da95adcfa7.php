

<?php $__env->startSection('content'); ?>
<h2>Ubah Produk: <?php echo e($product->name); ?></h2>

<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?> 
    <div class="mb-3">
        <label>Nama Produk</label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>" required>
    </div>
    
    <div class="mb-3">
        <label>Kategori</label>
        <select name="category_id" class="form-select">
            <option value="">-- Pilih Kategori --</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($cat->id); ?>" 
                    <?php echo e(old('category_id', $product->category_id) == $cat->id ? 'selected' : ''); ?>

                >
                    <?php echo e($cat->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    
    <div class="mb-3">
        <label>Harga</label>
        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>" required>
    </div>
    
    
    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="description" class="form-control"><?php echo e(old('description', $product->detail->description ?? '')); ?></textarea>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-3">
            <label>Berat (kg)</label>
            <input type="number" step="0.01" name="weight" class="form-control" value="<?php echo e(old('weight', $product->detail->weight ?? '')); ?>" required>
        </div>
        <div class="col-md-6 mb-3">
            <label>Ukuran</label>
            <input type="text" name="size" class="form-control" value="<?php echo e(old('size', $product->detail->size ?? '')); ?>">
        </div>
    </div>

    <button class="btn btn-primary">Simpan Perubahan</button>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/products/edit.blade.php ENDPATH**/ ?>