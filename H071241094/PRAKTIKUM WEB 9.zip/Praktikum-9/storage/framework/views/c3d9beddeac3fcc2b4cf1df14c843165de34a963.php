

<?php $__env->startSection('content'); ?>
<h2>Detail Gudang</h2>

<div class="card p-3">
    <p><strong>ID:</strong> <?php echo e($warehouse->id); ?></p>
    <p><strong>Nama Gudang:</strong> <?php echo e($warehouse->name); ?></p>
    <p><strong>Lokasi:</strong> <?php echo e($warehouse->location ?? '-'); ?></p>
</div>
    
    <p><strong>Dibuat pada:</strong> 
        <?php echo e($warehouse->created_at ? $warehouse->created_at->format('d M Y H:i') : '-'); ?>

    </p>
    <p><strong>Terakhir diperbarui:</strong> 
        <?php echo e($warehouse->updated_at ? $warehouse->updated_at->format('d M Y H:i') : '-'); ?>

    </p>
</div>
<h4 class="mt-4">Produk di Gudang Ini:</h4>
<?php if($warehouse->products->isNotEmpty()): ?>
    <table class="table table-bordered mt-2">
        <thead class="table-light">
            <tr>
                <th>Nama Produk</th>
                <th>Kategori</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $warehouse->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo e($p->category->name ?? '-'); ?></td>
                    <td><?php echo e($p->pivot->quantity); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="text-muted">Belum ada produk di gudang ini.</p>
<?php endif; ?>

<a href="<?php echo e(route('warehouses.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
<a href="<?php echo e(route('warehouses.edit', $warehouse->id)); ?>" class="btn btn-warning mt-3">Edit</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/warehouses/show.blade.php ENDPATH**/ ?>