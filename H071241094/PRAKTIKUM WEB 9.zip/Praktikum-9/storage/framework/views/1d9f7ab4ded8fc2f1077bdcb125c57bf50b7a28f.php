

<?php $__env->startSection('content'); ?>
<h2 class="mb-3">Daftar Kategori</h2>
<a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success mb-3">+ Tambah Kategori</a>

<table class="table table-bordered table-striped">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Kategori</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cat->id); ?></td>
            <td><?php echo e($cat->name); ?></td>
            <td><?php echo e($cat->description); ?></td>
            <td>
    <a href="<?php echo e(route('categories.show', $cat->id)); ?>" class="btn btn-info btn-sm">Detail</a> 
    <a href="<?php echo e(route('categories.edit', $cat->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
    <form action="<?php echo e(route('categories.destroy', $cat->id)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus kategori ini?')">Hapus</button>
    </form>
</td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/categories/index.blade.php ENDPATH**/ ?>