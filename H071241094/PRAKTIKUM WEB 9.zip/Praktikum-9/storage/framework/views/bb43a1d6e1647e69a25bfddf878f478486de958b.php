<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Product Manager</a>
            <div class="navbar-nav">
                <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">Kategori</a>
                <a class="nav-link" href="<?php echo e(route('warehouses.index')); ?>">Gudang</a>
                <a class="nav-link" href="<?php echo e(route('products.index')); ?>">Produk</a>
                <a class="nav-link" href="<?php echo e(route('stocks.index')); ?>">Stock</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/layout.blade.php ENDPATH**/ ?>