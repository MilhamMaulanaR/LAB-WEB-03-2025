

<?php $__env->startSection('content'); ?>
<h2 class="mb-3">Detail Kategori: <?php echo e($category->name); ?></h2>
<p><strong>Deskripsi:</strong> <?php echo e($category->description ?? '-'); ?></p>

<p><strong>Dibuat pada:</strong> <?php echo e($category->created_at ? $category->created_at->format('d M Y H:i') : '-'); ?></p>
<p><strong>Terakhir diperbarui:</strong> <?php echo e($category->updated_at ? $category->updated_at->format('d M Y H:i') : '-'); ?></p>
<hr>

<h4>Daftar Produk dalam Kategori Ini</h4>

<?php if($category->products->isEmpty()): ?>
    <div class="alert alert-warning">Belum ada produk dalam kategori ini.</div>
<?php else: ?>
<table class="table table-bordered table-striped mt-3">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Deskripsi</th>
            <th>Berat</th>
            <th>Ukuran</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e(number_format($product->price, 2)); ?></td>
            <td><?php echo e($product->description ?? '-'); ?></td>
            <td><?php echo e($product->weight ?? '-'); ?></td>
            <td><?php echo e($product->size ?? '-'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum-9\resources\views/categories/show.blade.php ENDPATH**/ ?>