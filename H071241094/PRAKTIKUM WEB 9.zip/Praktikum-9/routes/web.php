<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\WarehouseController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StockController;

Route::get('/', function () {
    return redirect()->route('products.index');
});

Route::resource('categories', CategoryController::class);
Route::resource('warehouses', WarehouseController::class);
Route::resource('products', ProductController::class);

//  Halaman utama stok (menampilkan daftar stok per gudang)
Route::get('stocks', [StockController::class, 'index'])->name('stocks.index');

//  Form untuk transfer stok
Route::get('stocks/transfer', [StockController::class, 'createTransfer'])->name('stocks.transfer');

//  Proses (POST) transfer stok
Route::post('stocks/transfer', [StockController::class, 'transfer'])->name('stocks.transfer.post');

Route::resource('categories', CategoryController::class);
