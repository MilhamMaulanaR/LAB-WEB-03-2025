@extends('layout')

@section('content')
<h2 class="mb-3">Detail Kategori: {{ $category->name }}</h2>
<p><strong>Deskripsi:</strong> {{ $category->description ?? '-' }}</p>
{{--  Tambahkan informasi waktu dibuat & diperbarui --}}
<p><strong>Dibuat pada:</strong> {{ $category->created_at ? $category->created_at->format('d M Y H:i') : '-' }}</p>
<p><strong>Terakhir diperbarui:</strong> {{ $category->updated_at ? $category->updated_at->format('d M Y H:i') : '-' }}</p>
<hr>

<h4>Daftar Produk dalam Kategori Ini</h4>

@if($category->products->isEmpty())
    <div class="alert alert-warning">Belum ada produk dalam kategori ini.</div>
@else
<table class="table table-bordered table-striped mt-3">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Deskripsi</th>
            <th>Berat</th>
            <th>Ukuran</th>
        </tr>
    </thead>
    <tbody>
        @foreach($category->products as $product)
        <tr>
            <td>{{ $product->id }}</td>
            <td>{{ $product->name }}</td>
            <td>{{ number_format($product->price, 2) }}</td>
            <td>{{ $product->description ?? '-' }}</td>
            <td>{{ $product->weight ?? '-' }}</td>
            <td>{{ $product->size ?? '-' }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@endif

<a href="{{ route('categories.index') }}" class="btn btn-secondary mt-3">Kembali</a>
@endsection
