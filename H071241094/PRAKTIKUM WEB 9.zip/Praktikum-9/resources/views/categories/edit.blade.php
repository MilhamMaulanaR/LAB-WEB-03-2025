@extends('layout')

@section('content')
<h2>Edit Kategori</h2>
<form action="{{ route('categories.update', $category->id) }}" method="POST">
    @csrf 
    @method('PUT')
    <div class="mb-3">
        <label>Nama Kategori</label>
        <input type="text" name="name" class="form-control" value="{{ $category->name }}" required>
    </div>
    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="description" class="form-control">{{ $category->description }}</textarea>
    </div>
    <div class="mb-3">
    <button type="submit" class="btn btn-primary me-2">Perbarui</button>
    <a href="{{ route('categories.edit', $category->id) }}" class="btn btn-warning me-2">Edit</a>
    <a href="{{ route('categories.index') }}" class="btn btn-secondary">Kembali</a>
</div>

</form>
@endsection
