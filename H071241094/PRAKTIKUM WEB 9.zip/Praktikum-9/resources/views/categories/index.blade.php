@extends('layout')

@section('content')
<h2 class="mb-3">Daftar Kategori</h2>
<a href="{{ route('categories.create') }}" class="btn btn-success mb-3">+ Tambah Kategori</a>

<table class="table table-bordered table-striped">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Kategori</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($categories as $cat)
        <tr>
            <td>{{ $cat->id }}</td>
            <td>{{ $cat->name }}</td>
            <td>{{ $cat->description }}</td>
            <td>
    <a href="{{ route('categories.show', $cat->id) }}" class="btn btn-info btn-sm">Detail</a> {{-- ✅ Tambahan tombol --}}
    <a href="{{ route('categories.edit', $cat->id) }}" class="btn btn-warning btn-sm">Edit</a>
    <form action="{{ route('categories.destroy', $cat->id) }}" method="POST" class="d-inline">
        @csrf 
        @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus kategori ini?')">Hapus</button>
    </form>
</td>

        </tr>
        @endforeach
    </tbody>
</table>
@endsection
