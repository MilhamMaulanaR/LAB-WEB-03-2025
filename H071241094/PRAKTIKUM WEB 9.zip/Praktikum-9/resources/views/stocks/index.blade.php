@extends('layout')

@section('content')

{{--  BAGIAN UTAMA: Tampilan List Produk per Gudang dengan Total --}}

<div class="row">
    <div class="col-md-12">
        <h3 class="mb-3">
             Ringkasan Stok Produk 
            {{ request('warehouse_id') ? 'di ' . ($warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang') : 'Global' }}
        </h3>

        {{-- Form Filter Gudang (Sesuai Persyaratan) --}}
        <form action="{{ route('stocks.index') }}" method="GET" class="mb-4">
            <select name="warehouse_id" class="form-select" onchange="this.form.submit()">
                <option value="">-- Tampilkan Total Stok Global --</option>
                @foreach($warehouses as $w)
                    <option value="{{ $w->id }}" {{ request('warehouse_id') == $w->id ? 'selected' : '' }}>
                        {{ $w->name }}
                    </option>
                @endforeach
            </select>
        </form>

        {{--  TAMPILAN STOK YANG DIKELOMPOKKAN BERDASARKAN KATEGORI (Sesuai Persyaratan) --}}
        {{--  CEK DATA STOK --}}
@if(isset($stocks) && $stocks->isNotEmpty())

    {{--  Loop kategori --}}
    @foreach($stocks as $category => $products)
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-dark text-white">
    <h4 class="mb-0">
     Kategori: {{ $category ?? '-' }}
    <span class="text-warning">
        ({{ request('warehouse_id') 
            ? ($warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang Tidak Diketahui') 
            : 'Global' }})
    </span>
</h4>

        @if(request('warehouse_id'))
            {{-- tampilkan nama gudang di sebelah kategori --}}
            ({{ $warehouses->firstWhere('id', request('warehouse_id'))->name ?? 'Gudang Tidak Diketahui' }})
        @else
            (Global)
        @endif
    </h4>
</div>


            <div class="card-body p-0">
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-light">
    <tr>
        <th>Produk</th>
        <th>Kategori</th>
        <th>{{ request('warehouse_id') ? 'Jumlah di Gudang' : 'Total Stok Global' }}</th>
    </tr>
</thead>
<tbody>
    @foreach($products as $p)
        <tr>
            <td>{{ $p->name }}</td>
            <td>{{ $p->category->name ?? '-' }}</td> {{--  Ambil dari relasi --}}
            <td>
                @if(request('warehouse_id'))
                    {{ $p->pivot->quantity ?? 0 }}
                @else
                    {{ $p->total_stock ?? 0 }}
                @endif
            </td>
        </tr>
    @endforeach
</tbody>

                </table>
            </div>
        </div>
    @endforeach

{{--  Jika gudang dipilih tapi stok kosong --}}
@elseif(request('warehouse_id') && $stocks->isEmpty())
    <div class="alert alert-info">
        Gudang yang dipilih saat ini tidak memiliki stok produk.
    </div>

{{--  Jika tidak ada stok sama sekali --}}
@else
    <div class="alert alert-warning">
        Tidak ditemukan data stok produk.
    </div>
@endif

<a href="{{ route('stocks.transfer') }}" class="btn btn-success mt-3">Transfer Stok</a>

    </div>
</div>

@endsection