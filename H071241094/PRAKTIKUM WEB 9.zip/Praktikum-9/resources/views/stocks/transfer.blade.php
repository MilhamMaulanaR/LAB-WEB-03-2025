@extends('layout')

@section('content')
<h2>Transfer Stok</h2>

<form action="{{ route('stocks.transfer') }}" method="POST">
    @csrf
    <div class="mb-3">
        <label>Gudang</label>
        <select name="warehouse_id" class="form-select" required>
            @foreach($warehouses as $w)
                <option value="{{ $w->id }}">{{ $w->name }}</option>
            @endforeach
        </select>
    </div>

    <div class="mb-3">
        <label>Produk</label>
        <select name="product_id" class="form-select" required>
            @foreach($products as $p)
                <option value="{{ $p->id }}">{{ $p->name }}</option>
            @endforeach
        </select>
    </div>

    <div class="mb-3">
        <label>Perubahan Jumlah (+/-)</label>
        <input type="number" name="quantity" class="form-control" placeholder="contoh: +10 atau -5" required>
    </div>

<div class="mb-3">
    <a href="{{ route('stocks.index') }}" class="btn btn-secondary me-2">Kembali</a>
    <button type="submit" class="btn btn-primary">Kirim</button>
</div>
</form>
@endsection

