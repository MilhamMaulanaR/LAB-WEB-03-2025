@extends('layout')

@section('content')
<h2>Tambah Produk</h2>

<form action="{{ route('products.store') }}" method="POST">
@csrf
<div class="mb-3">
    <label>Nama Produk</label>
    <input type="text" name="name" class="form-control" required>
</div>
<div class="mb-3">
    <label>Kategori</label>
<select name="category_id" class="form-select">
    <option value="">-- Pilih Kategori --</option>
    @foreach($categories as $cat)
        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
    @endforeach
</select>

</div>
<div class="mb-3">
    <label>Harga</label>
    <input type="number" step="0.01" name="price" class="form-control" required>
</div>
<div class="mb-3">
    <label>Deskripsi</label>
    <textarea name="description" class="form-control"></textarea>
</div>
<div class="row">
    <div class="col-md-6 mb-3">
        <label>Berat (kg)</label>
        <input type="number" step="0.01" name="weight" class="form-control" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Ukuran</label>
        <input type="text" name="size" class="form-control">
    </div>
</div>
<button class="btn btn-primary">Simpan</button>
<a href="{{ route('products.index') }}" class="btn btn-secondary">Kembali</a>
</form>
@endsection
