@extends('layout')

@section('content')
<h2>Ubah Produk: {{ $product->name }}</h2>

<form action="{{ route('products.update', $product->id) }}" method="POST">
@csrf
@method('PUT') {{-- PENTING: Gunakan method PUT/PATCH untuk update --}}
    <div class="mb-3">
        <label>Nama Produk</label>
        <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}" required>
    </div>
    
    <div class="mb-3">
        <label>Kategori</label>
        <select name="category_id" class="form-select">
            <option value="">-- Pilih Kategori --</option>
            @foreach($categories as $cat)
                {{-- Ini memastikan kategori yang sudah ada terpilih otomatis --}}
                <option value="{{ $cat->id }}" 
                    {{ old('category_id', $product->category_id) == $cat->id ? 'selected' : '' }}
                >
                    {{ $cat->name }}
                </option>
            @endforeach
        </select>
    </div>
    
    <div class="mb-3">
        <label>Harga</label>
        <input type="number" step="0.01" name="price" class="form-control" value="{{ old('price', $product->price) }}" required>
    </div>
    
    {{-- Tambahkan field detail lainnya, pastikan Anda mendapatkan nilai dari relasi detail --}}
    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="description" class="form-control">{{ old('description', $product->detail->description ?? '') }}</textarea>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-3">
            <label>Berat (kg)</label>
            <input type="number" step="0.01" name="weight" class="form-control" value="{{ old('weight', $product->detail->weight ?? '') }}" required>
        </div>
        <div class="col-md-6 mb-3">
            <label>Ukuran</label>
            <input type="text" name="size" class="form-control" value="{{ old('size', $product->detail->size ?? '') }}">
        </div>
    </div>

    <button class="btn btn-primary">Simpan Perubahan</button>
    <a href="{{ route('products.index') }}" class="btn btn-secondary">Kembali</a>
</form>
@endsection