@extends('layout')

@section('content')
<h2>Detail Produk</h2>

<p><strong>Nama Produk:</strong> {{ $product->name }}</p>
<p><strong>Kategori:</strong> {{ $product->category?->name ?? '-' }}</p>
<p><strong>Harga:</strong> Rp {{ number_format($product->price, 2, ',', '.') }}</p>
<p><strong>Deskripsi:</strong> {{ $product->detail->description ?? '-' }}</p>
<p><strong>Berat:</strong> {{ $product->detail->weight ?? '-' }} kg</p>
<p><strong>Ukuran:</strong> {{ $product->detail->size ?? '-' }}</p>

{{--  Tambahkan waktu dibuat & diperbarui --}}
<p><strong>Dibuat pada:</strong> {{ $product->created_at ? $product->created_at->format('d M Y H:i') : '-' }}</p>
<p><strong>Terakhir diperbarui:</strong> {{ $product->updated_at ? $product->updated_at->format('d M Y H:i') : '-' }}</p>

<a href="{{ route('products.index') }}" class="btn btn-secondary">Kembali</a>
@endsection
