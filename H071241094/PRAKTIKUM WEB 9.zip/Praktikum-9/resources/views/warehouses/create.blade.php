@extends('layout')

@section('content')
<h2>Tambah Gudang</h2>
<form action="{{ route('warehouses.store') }}" method="POST">
    @csrf
    <div class="mb-3">
        <label>Nama Gudang</label>
        <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Lokasi</label>
        <textarea name="location" class="form-control"></textarea>
    </div>
    <button class="btn btn-primary">Simpan</button>
    <a href="{{ route('warehouses.index') }}" class="btn btn-secondary">Kembali</a>
</form>
@endsection
