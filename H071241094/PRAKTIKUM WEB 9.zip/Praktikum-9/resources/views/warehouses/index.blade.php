@extends('layout')

@section('content')
<h2>Daftar Gudang</h2>
<a href="{{ route('warehouses.create') }}" class="btn btn-success mb-3">+ Tambah Gudang</a>

<table class="table table-bordered">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Nama Gudang</th>
            <th>Lokasi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($warehouses as $wh)
        <tr>
            <td>{{ $wh->id }}</td>
            <td>{{ $wh->name }}</td>
            <td>{{ $wh->location }}</td>
            <td>
    <a href="{{ route('warehouses.show', $wh->id) }}" class="btn btn-info btn-sm">Detail</a>
    <a href="{{ route('warehouses.edit', $wh->id) }}" class="btn btn-warning btn-sm">Ubah</a>
    <form action="{{ route('warehouses.destroy', $wh->id) }}" method="POST" class="d-inline">
        @csrf 
        @method('DELETE')
        <button class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus gudang ini?')">Hapus</button>
    </form>
</td>

        </tr>
        @empty
        <tr>
            <td colspan="4" class="text-center text-muted">Belum ada data gudang.</td>
        </tr>
        @endforelse
    </tbody>
</table>
@endsection
