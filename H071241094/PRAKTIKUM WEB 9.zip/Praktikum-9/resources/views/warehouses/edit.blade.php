@extends('layout')

@section('content')
<h2>Edit Gudang</h2>
<form action="{{ route('warehouses.update', $warehouse->id) }}" method="POST">
    @csrf 
    @method('PUT')
    <div class="mb-3">
        <label>Nama Gudang</label>
        <input type="text" name="name" class="form-control" value="{{ $warehouse->name }}">
    </div>
    <div class="mb-3">
        <label>Lokasi</label>
        <textarea name="location" class="form-control">{{ $warehouse->location }}</textarea>
    </div>
    <button class="btn btn-primary">Perbarui</button>
    <a href="{{ route('warehouses.index') }}" class="btn btn-secondary">Kembali</a>
</form>
@endsection
