@extends('layout')

@section('content')
<h2>Detail Gudang</h2>

<div class="card p-3">
    <p><strong>ID:</strong> {{ $warehouse->id }}</p>
    <p><strong>Nama Gudang:</strong> {{ $warehouse->name }}</p>
    <p><strong>Lokasi:</strong> {{ $warehouse->location ?? '-' }}</p>
</div>
    {{--  Tambahan waktu dibuat & diperbarui --}}
    <p><strong>Dibuat pada:</strong> 
        {{ $warehouse->created_at ? $warehouse->created_at->format('d M Y H:i') : '-' }}
    </p>
    <p><strong>Terakhir diperbarui:</strong> 
        {{ $warehouse->updated_at ? $warehouse->updated_at->format('d M Y H:i') : '-' }}
    </p>
</div>
<h4 class="mt-4">Produk di Gudang Ini:</h4>
@if($warehouse->products->isNotEmpty())
    <table class="table table-bordered mt-2">
        <thead class="table-light">
            <tr>
                <th>Nama Produk</th>
                <th>Kategori</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            @foreach($warehouse->products as $p)
                <tr>
                    <td>{{ $p->name }}</td>
                    <td>{{ $p->category->name ?? '-' }}</td>
                    <td>{{ $p->pivot->quantity }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@else
    <p class="text-muted">Belum ada produk di gudang ini.</p>
@endif

<a href="{{ route('warehouses.index') }}" class="btn btn-secondary mt-3">Kembali</a>
<a href="{{ route('warehouses.edit', $warehouse->id) }}" class="btn btn-warning mt-3">Edit</a>

@endsection
