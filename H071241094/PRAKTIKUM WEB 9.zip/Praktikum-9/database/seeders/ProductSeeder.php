<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\ProductDetail;
use App\Models\Category;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $electronics = Category::where('name', 'Elektronik')->first();

        $product1 = Product::create([
            'name' => 'TV Samsung 32 Inch',
            'price' => 3200000,
            'category_id' => $electronics->id ?? null,
        ]);

        ProductDetail::create([
            'product_id' => $product1->id,
            'description' => 'Smart TV Full HD',
            'weight' => 5.4,
            'size' => '32 inch',
        ]);

        $product2 = Product::create([
            'name' => 'Kulkas LG 2 Pintu',
            'price' => 5200000,
            'category_id' => $electronics->id ?? null,
        ]);

        ProductDetail::create([
            'product_id' => $product2->id,
            'description' => 'Hemat listrik, kapasitas besar',
            'weight' => 35.2,
            'size' => '170x60x55 cm',
        ]);
    }
}
