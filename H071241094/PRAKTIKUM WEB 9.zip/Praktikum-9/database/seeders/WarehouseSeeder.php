<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Warehouse;

class WarehouseSeeder extends Seeder
{
    public function run(): void
    {
        Warehouse::create(['name' => 'Gudang Jakarta', 'location' => 'Jl. Merdeka No. 10, Jakarta']);
        Warehouse::create(['name' => 'Gudang Surabaya', 'location' => 'Jl. Pahlawan No. 25, Surabaya']);
    }
}
