<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        Category::create(['name' => 'Elektronik', 'description' => 'Perangkat elektronik rumah tangga']);
        Category::create(['name' => 'Furniture', 'description' => 'Perabot rumah tangga']);
        Category::create(['name' => 'Fashion', 'description' => 'Pakaian dan aksesoris']);
    }
}
