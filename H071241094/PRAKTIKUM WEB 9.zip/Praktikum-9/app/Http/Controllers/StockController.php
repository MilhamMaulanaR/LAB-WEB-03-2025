<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Warehouse;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockController extends Controller
{
    // 🔹 Menampilkan halaman daftar stok
    public function index(Request $request)
    {
        // 1. Ambil semua gudang untuk dropdown filter
        $warehouses = Warehouse::all();

        // 2. Ambil daftar kategori (pakai tabel categories, bukan products)
        $categories = Category::pluck('name', 'id')->sortKeys();

        $warehouseId = $request->input('warehouse_id');
        $stocks = collect(); // Default koleksi kosong

        if ($warehouseId) {
            // A. LOGIKA FILTER: Tampilkan stok di gudang tertentu (Per Gudang)
            $warehouse = Warehouse::with(['products' => function ($query) {
                // Pilih kolom penting dan tambahkan relasi kategori
                $query->select('products.id', 'products.name', 'products.category_id')
                      ->with('category')
                      ->withPivot('quantity')
                      ->orderBy('products.category_id')
                      ->orderBy('products.name');
            }])->find($warehouseId);

            if ($warehouse) {
                // Kelompokkan produk berdasarkan kategori (pakai category_id)
                $stocks = $warehouse->products->groupBy(function ($product) {
                    return $product->category->name ?? 'Tanpa Kategori';
                });
            }
        } else {
    // B. LOGIKA STOK GLOBAL: Hitung total stok dari semua gudang
    $stocksRaw = Product::with(['category', 'warehouses']) //  ambil relasi kategori & gudang
        ->get()
        ->map(function ($product) {
            $product->total_quantity = $product->warehouses->sum('pivot.quantity');
            return $product;
        });

    //  Kelompokkan berdasarkan nama kategori
    $stocks = $stocksRaw->groupBy(function ($product) {
        return $product->category->name ?? 'Tanpa Kategori';
    });
}

        // Kirim ke view
        return view('stocks.index', compact('warehouses', 'stocks', 'categories'));
    }

    // 🔹 Menampilkan form untuk transfer stok
    public function createTransfer()
    {
        $warehouses = Warehouse::all();
        $products = Product::all();
        return view('stocks.transfer', compact('warehouses', 'products'));
    }

    // 🔹 Menangani proses transfer stok (POST)
    public function transfer(Request $request)
    {
        $request->validate([
            'warehouse_id' => 'required|exists:warehouses,id',
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer',
        ]);

        DB::transaction(function () use ($request) {
            $warehouse = Warehouse::find($request->warehouse_id);
            $product = Product::find($request->product_id);

            $currentStock = DB::table('product_warehouse')
                ->where('warehouse_id', $warehouse->id)
                ->where('product_id', $product->id)
                ->value('quantity');

            $currentQty = $currentStock ?? 0;
            $newQty = $currentQty + $request->quantity;

            if ($newQty < 0) {
                throw new \Exception('Stok tidak boleh negatif! Stok saat ini: ' . $currentQty);
            }

            $warehouse->products()->syncWithoutDetaching([
                $product->id => ['quantity' => $newQty],
            ]);
        });

        return redirect()->route('stocks.index')->with('success', 'Stok berhasil diperbarui!');
    }
}
