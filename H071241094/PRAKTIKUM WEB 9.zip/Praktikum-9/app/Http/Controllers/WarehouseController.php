<?php

namespace App\Http\Controllers;

use App\Models\Warehouse;
use Illuminate\Http\Request;


class WarehouseController extends Controller
{
    //  Menampilkan daftar semua gudang
    public function index()
    {
        $warehouses = Warehouse::all();
        return view('warehouses.index', compact('warehouses'));
    }

    //  Menampilkan form untuk membuat gudang baru
    public function create()
    {
        return view('warehouses.create');
    }

    //  Menyimpan gudang baru ke database
    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required|string|max:255',
            'location' => 'nullable|string|max:255',
        ]);
        Warehouse::create($request->only('name', 'location')); 

        return redirect()->route('warehouses.index')->with('success', 'Gudang berhasil dibuat!');
    }

    //  Menampilkan form untuk mengedit gudang
    public function edit($id)
    {
        $warehouse = Warehouse::findOrFail($id);
        return view('warehouses.edit', compact('warehouse'));
    }

    //  Memperbarui gudang di database
    public function update(Request $request, $id)
    {
     
        $request->validate([
            'name' => 'required|string|max:255',
            'location' => 'nullable|string|max:255',
        ]);

        $warehouse = Warehouse::findOrFail($id);
        $warehouse->update($request->only('name', 'location'));

        return redirect()->route('warehouses.index')->with('success', 'Gudang berhasil diperbarui!');
    }

    //  Menghapus gudang dari database (dengan pemeriksaan stok)
    public function destroy($id)
    {
        $warehouse = Warehouse::findOrFail($id);
        
        // --- LOGIKA PENCEGAHAN PENGHAPUSAN (INTEGRITAS DATA) ---
        
        // Hitung jumlah jenis produk yang terhubung dengan gudang ini 
        // (yaitu, jumlah entri di tabel pivot product_warehouse).
        $stockCount = $warehouse->products()->count(); 

        if ($stockCount > 0) {
            // Jika gudang memiliki relasi dengan produk (stok > 0), kembalikan pesan error.
            return redirect()->route('warehouses.index')
                             ->with('error', "Gagal menghapus! Gudang '{$warehouse->name}' masih memiliki {$stockCount} jenis produk yang tersimpan. Kosongkan gudang terlebih dahulu.");
        }
        
        $warehouse->delete();

        return redirect()->route('warehouses.index')->with('success', 'Gudang berhasil dihapus!');
    }
    public function show($id)
{
    $warehouse = Warehouse::with('products')->findOrFail($id);
    return view('warehouses.show', compact('warehouse'));
}

}