<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Warehouse extends Model
{
    use HasFactory;
protected $fillable = ['name', 'location'];
    // ... (property lain jika ada)

    // Definisikan relasi Many-to-Many ke Product.
    // Asumsi tabel pivot: product_warehouse
    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_warehouse')
                    ->withPivot('quantity'); // WAJIB ada agar quantity bisa diakses
    }
}