@extends('layouts.master')

@section('title', 'Peta Wisata - Eksplor Manokwari')

@section('content')

<style>
@keyframes fadeInUp { from {opacity:0; transform:translateY(30px);} to {opacity:1; transform:translateY(0);} }
@keyframes fadeInDown { from {opacity:0; transform:translateY(-30px);} to {opacity:1; transform:translateY(0);} }
@keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }

.animate-fadeInUp { animation: fadeInUp 0.8s ease-out both; }
.animate-fadeInDown { animation: fadeInDown 0.8s ease-out both; }
.animate-float { animation: float 3s ease-in-out infinite; }

.gallery-item {
    animation: scaleIn 0.7s ease-out both;
}
.gallery-item:nth-child(odd) { animation-delay: 0.1s; }
.gallery-item:nth-child(even) { animation-delay: 0.2s; }
</style>

<!--HERO SECTION -->
<div class="relative mb-15 parallax-bg text-center py-16">
    <h2 class="text-5xl md:text-7xl font-extrabold text-blue-700 mb-4 animate-fadeInDown">
        Peta Wisata Manokwari
    </h2>
    <p class="text-xl md:text-2xl text-gray-700 font-medium animate-fadeInUp delay-200 mb-6">
        Temukan lokasi wisata menarik di sekitar Manokwari.
    </p>
    <div class="flex justify-center gap-2 animate-fadeInUp delay-300">
        <span class="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse delay-100"></span>
    </div>
</div>

<!-- Peta -->
<div class="max-w-6xl mx-auto mb-12 rounded-3xl overflow-hidden shadow-2xl">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127483.08405699634!2d134.06285485!3d-0.86295885!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d540b5d888502e5%3A0x4030bfbca7e3490!2sManokwari%2C%20Manokwari%20Regency%2C%20West%20Papua!5e0!3m2!1sen!2sid!4v1234567890"
        width="100%"
        height="500"
        style="border:0;"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<!-- Daftar Destinasi Wisata -->
<div class="max-w-6xl mx-auto bg-gradient-to-br from-blue-50 to-indigo-100 p-10 rounded-3xl shadow-xl">
    <h3 class="text-3xl font-bold text-blue-900 mb-8 text-center">📍 Daftar Destinasi Wisata</h3>

    <div class="grid md:grid-cols-2 gap-6">
        <!-- Pantai Pasir Putih -->
        <a href="https://maps.google.com/?q=Pantai+Pasir+Putih+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-blue-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-blue-800">Pantai Pasir Putih</h4>
            <p class="text-gray-600">Jl. Pasir Putih, Pasir Putih, Kec. Manokwari Timur., Kabupaten Manokwari, Papua Barat.</p>
            <span class="text-blue-500 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Pulau Mansinam -->
        <a href="https://maps.google.com/?q=Pulau+Mansinam+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-indigo-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-indigo-700">Pulau Mansinam</h4>
            <p class="text-gray-600">Mansinam, Kec. Manokwari Timur. Kabupaten Manokwari, Papua Barat.</p>
            <span class="text-indigo-500 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Pantai Bakaro -->
        <a href="https://maps.google.com/?q=Pantai+Bakaro+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-yellow-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-yellow-700">Pantai Bakaro</h4>
            <p class="text-gray-600">Sunsweni, Kec. Manokwari Barat. Kabupaten Manokwari, Papua Barat.</p>
            <span class="text-yellow-600 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Pantai Amban -->
        <a href="https://maps.google.com/?q=Pantai+Amban+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-cyan-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-cyan-700">Pantai Amban</h4>
            <p class="text-gray-600">Amban, Manokwari Utara</p>
            <span class="text-cyan-600 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Pantai Sidey -->
        <a href="https://maps.google.com/?q=Pantai+Sidey+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-sky-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-sky-700">Pantai Sidey</h4>
            <p class="text-gray-600">Sidey, Distrik Sidey, Kabupaten Manokwari, Papua Barat.</p>
            <span class="text-sky-600 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Danau Anggi Giji & Gita -->
        <a href="https://maps.google.com/?q=Danau+Anggi+Giji+Gita+Pegunungan+Arfak" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-blue-100 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-blue-800">Danau Anggi Giji & Gita</h4>
            <p class="text-gray-600">Pegunungan Arfak, Manokwari</p>
            <span class="text-blue-600 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Gunung Meja -->
        <a href="https://maps.google.com/?q=Gunung+Meja+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-green-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-green-800">Gunung Meja</h4>
            <p class="text-gray-600">Kawasan Cagar Alam Gunung Meja, Manokwari</p>
            <span class="text-green-500 text-sm">Lihat di Google Maps</span>
        </a>

        <!-- Gunung Botak -->
        <a href="https://maps.google.com/?q=Gunung+Botak+Manokwari" target="_blank"
           class="block bg-white rounded-xl shadow-md p-5 hover:bg-lime-50 hover:shadow-lg transition">
            <h4 class="text-xl font-semibold text-lime-700">Gunung Botak</h4>
            <p class="text-gray-600">Daerah Amban, Manokwari</p>
            <span class="text-lime-600 text-sm">Lihat di Google Maps</span>
        </a>
    </div>

    <!-- Tombol Lihat Peta Lengkap -->
    <div class="text-center mt-10">
        <a href="https://www.google.com/maps/place/Manokwari,+West+Papua" target="_blank"
           class="inline-flex items-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-lg rounded-full shadow-lg transition transform hover:scale-105">
            Lihat Peta Lengkap di Google Maps
        </a>
    </div>
</div>
@endsection
