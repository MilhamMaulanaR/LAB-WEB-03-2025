
@extends('layouts.master')

@section('title', 'Kontak - Eksplor Manokwari')

@section('content')
<!-- Hero Section -->
<div class="text-center mb-16 mt-11 relative overflow-hidden">
    <style>
        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(40px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes fadeInDown {
            0% {
                opacity: 0;
                transform: translateY(-40px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .animate-fadeInUp {
            animation: fadeInUp 1s ease-out forwards;
        }

        .animate-fadeInDown {
            animation: fadeInDown 1s ease-out forwards;
        }
    </style>

    <div class="absolute inset-0 -z-10">
        <div class="absolute top-20 left-1/4 w-72 h-72 bg-blue-300/20 rounded-full blur-3xl animate-fadeInDown"></div>
        <div class="absolute top-40 right-1/4 w-96 h-96 bg-indigo-300/20 rounded-full blur-3xl animate-fadeInUp"></div>
    </div>
    
    <h2 class="text-5xl md:text-7xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-900 animate-fadeInDown">
        Hubungi Kami
    </h2>
    <p class="text-xl md:text-2xl text-gray-700 max-w-3xl mx-auto font-light animate-fadeInUp">
        Ada pertanyaan? Kami siap membantu perjalanan Anda! 
    </p>
</div>


<!-- Formulir Kontak -->
<div class="max-w-3xl mx-auto mb-16">
    <div class="bg-gradient-to-br from-white to-blue-50 rounded-3xl shadow-2xl p-8 md:p-10 border-2 border-blue-100 hover:shadow-blue-200 hover:shadow-3xl transition-all duration-500 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-40 h-40 bg-blue-100/50 rounded-full -mr-20 -mt-20 blur-2xl"></div>
        <div class="absolute bottom-0 left-0 w-32 h-32 bg-indigo-100/50 rounded-full -ml-16 -mb-16 blur-2xl"></div>

        <div class="mb-8 text-center relative z-10">
            <div class="inline-block mb-4">
            </div>
            <h3 class="text-3xl font-bold bg-gradient-to-r from-blue-700 to-indigo-800 bg-clip-text text-transparent mb-2">Kirim Pesan</h3>
            <p class="text-gray-600">Isi form di bawah dan kami akan segera merespons</p>
        </div>

        <form class="space-y-6 relative z-10">
            <div>
                <label for="nama" class="block text-blue-900 font-semibold mb-2">Nama Lengkap *</label>
                <input type="text" id="nama" name="nama" class="w-full px-5 py-4 border-2 border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 bg-white" placeholder="Fandri" required>
            </div>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label for="email" class="block text-blue-900 font-semibold mb-2">Email *</label>
                    <input type="email" id="email" name="email" class="w-full px-5 py-4 border-2 border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 bg-white" placeholder="fandriku@gmail.com" required>
                </div>
                <div>
                    <label for="telepon" class="block text-blue-900 font-semibold mb-2">Nomor Telepon</label>
                    <input type="tel" id="telepon" name="telepon" class="w-full px-5 py-4 border-2 border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 bg-white" placeholder="+62 812 3456 7890">
                </div>
            </div>

            <div>
                <label for="subjek" class="block text-blue-900 font-semibold mb-2">Subjek *</label>
                <select id="subjek" name="subjek" class="w-full px-5 py-4 border-2 border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 bg-white" required>
                    <option value="">Pilih subjek pesan</option>
                    <option value="info">Informasi Umum</option>
                    <option value="paket">Paket Wisata</option>
                    <option value="kuliner">Rekomendasi Kuliner</option>
                    <option value="akomodasi">Akomodasi</option>
                    <option value="lainnya">Lainnya</option>
                </select>
            </div>

            <div>
                <label for="pesan" class="block text-blue-900 font-semibold mb-2">Pesan *</label>
                <textarea id="pesan" name="pesan" rows="5" class="w-full px-5 py-4 border-2 border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 resize-none bg-white" placeholder="Tulis pesan Anda di sini..." required></textarea>
            </div>

            <button type="submit" class="w-full bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 hover:from-blue-800 hover:to-indigo-950 text-white font-bold py-4 px-8 rounded-xl transition duration-300 transform hover:scale-[1.02] shadow-xl">
                <span class="flex items-center justify-center gap-2">Kirim Pesan <span>📨</span></span>
            </button>
        </form>
    </div>
</div>

<!-- FAQ Section - RATA TENGAH -->
<div class="bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-100 rounded-3xl shadow-xl p-8 md:p-12 mb-16 border border-blue-200">
    <div class="text-center mb-12">
        <div class="inline-block mb-4">
            <div class="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-full flex items-center justify-center shadow-lg">
                <span class="text-4xl">❓</span>
            </div>
        </div>
        <h3 class="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-700 to-indigo-800 bg-clip-text text-transparent mb-4">Pertanyaan Umum</h3>
        <p class="text-gray-700 text-lg">Jawaban untuk pertanyaan yang sering ditanyakan</p>
    </div>
    
    <div class="max-w-4xl mx-auto space-y-4">
        <div class="bg-white border-2 border-blue-200 rounded-2xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-200/50 transition-all duration-300 group">
            <h4 class="font-bold text-lg text-blue-900 mb-3 flex items-center gap-3">
                <span class="text-2xl group-hover:scale-110 transition-transform duration-300">📅</span>
                <span>Kapan waktu terbaik berkunjung ke Manokwari?</span>
            </h4>
            <p class="text-gray-700 pl-11">
                Waktu terbaik adalah April hingga Oktober (musim kemarau). Cuaca cerah ideal untuk aktivitas outdoor, diving, dan snorkeling.
            </p>
        </div>
        
        <div class="bg-white border-2 border-blue-200 rounded-2xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-200/50 transition-all duration-300 group">
            <h4 class="font-bold text-lg text-blue-900 mb-3 flex items-center gap-3">
                <span class="text-2xl group-hover:scale-110 transition-transform duration-300">✈️</span>
                <span>Bagaimana cara mencapai Manokwari?</span>
            </h4>
            <p class="text-gray-700 pl-11">
                Akses melalui Bandara Rendani Manokwari dengan penerbangan dari Jakarta, Makassar, atau Sorong. Tersedia juga jalur laut dari kota-kota lain di Papua.
            </p>
        </div>
        
        <div class="bg-white border-2 border-blue-200 rounded-2xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-200/50 transition-all duration-300 group">
            <h4 class="font-bold text-lg text-blue-900 mb-3 flex items-center gap-3">
                <span class="text-2xl group-hover:scale-110 transition-transform duration-300">🏨</span>
                <span>Apakah tersedia akomodasi di Manokwari?</span>
            </h4>
            <p class="text-gray-700 pl-11">
                Ya! Tersedia berbagai pilihan dari hotel berbintang, guesthouse, hingga homestay. Kami dapat membantu merekomendasikan akomodasi sesuai budget Anda.
            </p>
        </div>
        
        <div class="bg-white border-2 border-blue-200 rounded-2xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-200/50 transition-all duration-300 group">
            <h4 class="font-bold text-lg text-blue-900 mb-3 flex items-center gap-3">
                <span class="text-2xl group-hover:scale-110 transition-transform duration-300">💰</span>
                <span>Berapa budget yang dibutuhkan untuk wisata ke Manokwari?</span>
            </h4>
            <p class="text-gray-700 pl-11">
                Budget bervariasi tergantung durasi dan jenis wisata. Untuk 3-4 hari termasuk akomodasi, makan, dan tur, budget sekitar Rp 3-5 juta per orang.
            </p>
        </div>
        
        <div class="bg-white border-2 border-blue-200 rounded-2xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-200/50 transition-all duration-300 group">
            <h4 class="font-bold text-lg text-blue-900 mb-3 flex items-center gap-3">
                <span class="text-2xl group-hover:scale-110 transition-transform duration-300">👨‍✈️</span>
                <span>Apakah perlu menggunakan pemandu wisata?</span>
            </h4>
            <p class="text-gray-700 pl-11">
                Sangat disarankan, terutama untuk destinasi seperti Pegunungan Arfak dan spot diving. Pemandu lokal memastikan keamanan dan pengalaman yang lebih mendalam.
            </p>
        </div>
    </div>
</div>

<!--  Informasi Kontak -->
<div class="bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 rounded-3xl shadow-2xl p-10 md:p-16 text-white relative overflow-hidden mt-16">
    <div class="absolute inset-0 bg-gradient-to-b from-blue-400/10 to-indigo-600/10 blur-3xl"></div>

    <div class="relative z-10 text-center mb-12">
        <h3 class="text-3xl md:text-4xl font-extrabold mb-3 tracking-tight">Informasi Kontak</h3>
        <p class="text-blue-100 text-lg max-w-2xl mx-auto">
            Hubungi kami melalui kontak dan media sosial berikut — klik ikon untuk membuka tautan!
        </p>
    </div>

    <!-- 🔗 Daftar Kontak -->
    <div class="relative z-10 flex flex-wrap justify-center gap-8 md:gap-12 text-center">

        <!-- Telepon -->
        <a href="tel:0852-5452-6198" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-blue-400 group-hover:to-indigo-500 group-hover:shadow-blue-500/50">
                <span class="text-3xl">📞</span>
            </div>
            <p class="text-sm text-blue-200">Telepon</p>
        </a>

        <!-- Gmail -->
        <a href="mailto:eksplormanokwari@gmail.com" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-rose-500/20 to-red-500/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-rose-400 group-hover:to-red-500 group-hover:shadow-rose-500/50">
                <span class="text-3xl">✉️</span>
            </div>
            <p class="text-sm text-blue-200">Email</p>
        </a>

        <!-- Facebook -->
        <a href="https://www.facebook.com/share/g/1Cq6t853cm/?mibextid=wwXIfr" target="_blank" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-blue-600/20 to-indigo-600/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-blue-500 group-hover:to-indigo-600 group-hover:shadow-blue-500/50">
                <span class="text-3xl">📘</span>
            </div>
            <p class="text-sm text-blue-200">Facebook</p>
        </a>

        <!-- Instagram -->
        <a href="https://www.instagram.com/kabar_manokwari?igsh=ZGR1amw0dG9peTBp target="_blank" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-pink-500 group-hover:to-purple-500 group-hover:shadow-pink-500/50">
                <span class="text-3xl">📷</span>
            </div>
            <p class="text-sm text-blue-200">Instagram</p>
        </a>

        <!-- YouTube -->
        <a href="www.youtube.com/@tribunpapuabarat" target="_blank" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-red-500/20 to-orange-500/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-red-500 group-hover:to-orange-500 group-hover:shadow-red-500/50">
                <span class="text-3xl">▶️</span>
            </div>
            <p class="text-sm text-blue-200">YouTube</p>
        </a>

        <!-- Twitter / X -->
        <a href="https://x.com/eksplormanokwari" target="_blank" 
           class="group flex flex-col items-center transition-all hover:scale-110">
            <div class="w-16 h-16 bg-gradient-to-br from-sky-500/20 to-blue-500/20 rounded-2xl flex items-center justify-center mb-3 shadow-lg border border-white/10 group-hover:from-sky-400 group-hover:to-blue-500 group-hover:shadow-sky-500/50">
                <span class="text-3xl">🐦</span>
            </div>
            <p class="text-sm text-blue-200">Twitter (X)</p>
        </a>
    </div>
</div>

@endsection
