@extends('layouts.master')

@section('title', 'Kuliner - Eksplor Manokwari')

@section('content')
<style>
@keyframes fadeInUp { from {opacity:0; transform:translateY(30px);} to {opacity:1; transform:translateY(0);} }
@keyframes fadeInDown { from {opacity:0; transform:translateY(-30px);} to {opacity:1; transform:translateY(0);} }
@keyframes slideInLeft { from {opacity:0; transform:translateX(-50px);} to {opacity:1; transform:translateX(0);} }
@keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-12px);} }


.animate-fadeInUp { animation: fadeInUp 0.8s ease-out both; }
.animate-fadeInDown { animation: fadeInDown 0.8s ease-out both; }
.animate-slideInLeft { animation: slideInLeft 0.8s ease-out both; }
.animate-float { animation: float 3s ease-in-out infinite; }

.delay-100 { animation-delay: 0.1s; }
.delay-200 { animation-delay: 0.2s; }
.delay-300 { animation-delay: 0.3s; }
.delay-400 { animation-delay: 0.4s; }
.delay-500 { animation-delay: 0.5s; }
.delay-600 { animation-delay: 0.6s; }

.card-hover { transition: all .4s cubic-bezier(.175,.885,.32,1.275); }
.card-hover:hover { transform: translateY(-8px) scale(1.03); }

.glass-effect {
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(59,130,246,0.2);
    box-shadow: 0 10px 25px rgba(0,0,0,0.05);
}

.tip-card {
    position: relative;
    overflow: hidden;
    transition: all .3s ease;
}
.tip-card::before {
    content: '';
    position: absolute;
    top: 0; left: -100%;
    width: 100%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(59,130,246,.15), transparent);
    transition: left .6s ease;
}
.tip-card:hover::before { left: 100%; }

.parallax-bg {
    background-image:
        radial-gradient(circle at 20% 50%, rgba(59,130,246,0.08) 0%, transparent 60%),
        radial-gradient(circle at 80% 80%, rgba(96,165,250,0.08) 0%, transparent 60%);
}

@media (max-width: 768px) {
    h2 { font-size: 2.2rem; }
}
</style>

<!--HERO SECTION -->
<div class="relative mb-15 parallax-bg text-center py-16">
    <h2 class="text-5xl md:text-7xl font-extrabold text-blue-700 mb-4 animate-fadeInDown">
        Kuliner Khas Manokwari
    </h2>
    <p class="text-xl md:text-2xl text-gray-700 font-medium animate-fadeInUp delay-200 mb-6">
        Rasakan cita rasa autentik Papua Barat yang menggugah selera.
    </p>
    <div class="flex justify-center gap-2 animate-fadeInUp delay-300">
        <span class="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse delay-100"></span>
    </div>
</div>

<!-- HIDANGAN UTAMA -->
<div class="max-w-6xl mx-auto mb-20 px-4">
    <div class="grid md:grid-cols-3 gap-8">
        <div class="opacity-0 animate-fadeInUp delay-100 card-hover">
            <x-card 
                image="/images/papeda.png"
                title="Papeda"
                description="Makanan pokok khas Papua dari sagu yang disajikan dengan kuah kuning ikan tongkol penuh rempah."
            />
        </div>
        <div class="opacity-0 animate-fadeInUp delay-300 card-hover">
            <x-card 
                image="/images/ikan bakar.png"
                title="Ikan Bakar Manokwari"
                description="Ikan tongkol atau cakalang dibakar dengan sambal mentah khas Manokwari — pedas, segar, dan nikmat!"
            />
        </div>
        <div class="opacity-0 animate-fadeInUp delay-500 card-hover">
            <x-card 
                image="/images/udang.png"
                title="Udang Selingkuh"
                description="Udang air tawar besar khas Papua, digoreng atau dibakar dengan cita rasa gurih alami."
            />
        </div>
    </div>
</div>

<!--CAMILAN & OLEH-OLEH -->
<div class="max-w-6xl mx-auto mb-20 px-4">
    <div class="grid md:grid-cols-3 gap-8">
        <div class="opacity-0 animate-fadeInUp delay-200 card-hover">
            <x-card 
                image="/images/abon gulung.png"
                title="Abon Gulung"
                description="Abon sapi gurih dibungkus roti lembut dan dipanggang — oleh-oleh ikonik dari Manokwari."
            />
        </div>
        <div class="opacity-0 animate-fadeInUp delay-400 card-hover">
            <x-card 
                image="/images/Buah Merah.png"
                title="Buah Merah"
                description="Buah khas Papua kaya antioksidan, sering dijadikan minyak herbal alami untuk kesehatan."
            />
        </div>
        <div class="opacity-0 animate-fadeInUp delay-600 card-hover">
            <x-card 
                image="/images/sagu lempeng.png"
                title="Sagu Lempeng"
                description="Kue tradisional sagu yang dipanggang hingga renyah, manis dan cocok untuk teman kopi sore."
            />
        </div>
    </div>
</div>

<!-- ITPS KULINER -->
<div class="glass-effect border-l-4 border-blue-600 p-10 rounded-3xl shadow-xl max-w-6xl mx-auto mb-20 opacity-0 animate-fadeInUp delay-300">
    <div class="flex items-start gap-6">
        <span class="text-6xl flex-shrink-0 animate-pulse">💡</span>
        <div class="flex-1">
            <h3 class="text-3xl md:text-4xl font-extrabold text-blue-800 mb-8">Tips Menikmati Kuliner Manokwari</h3>
            <div class="grid md:grid-cols-2 gap-6">
                <div class="tip-card bg-white p-6 rounded-2xl shadow-md border border-blue-100 flex items-center gap-3">
                    <span class="text-3xl">🌅</span>
                    <p class="text-gray-700 font-medium">Coba papeda di pagi hari untuk rasa paling autentik.</p>
                </div>
                <div class="tip-card bg-white p-6 rounded-2xl shadow-md border border-blue-100 flex items-center gap-3">
                    <span class="text-3xl">🏪</span>
                    <p class="text-gray-700 font-medium">Kunjungi Pasar Sanggeng untuk mencicipi kuliner rakyat asli Manokwari.</p>
                </div>
                <div class="tip-card bg-white p-6 rounded-2xl shadow-md border border-blue-100 flex items-center gap-3">
                    <span class="text-3xl">🌊</span>
                    <p class="text-gray-700 font-medium">Nikmati ikan bakar segar di pinggir pantai sambil menatap sunset.</p>
                </div>
                <div class="tip-card bg-white p-6 rounded-2xl shadow-md border border-blue-100 flex items-center gap-3">
                    <span class="text-3xl">🎁</span>
                    <p class="text-gray-700 font-medium">Bawa pulang sagu lempeng atau abon gulung sebagai oleh-oleh khas.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
