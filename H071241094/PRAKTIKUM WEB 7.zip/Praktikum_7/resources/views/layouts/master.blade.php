<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title', 'Eksplor Manokwari')</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
    * { font-family: 'Poppins', sans-serif; }
    .hero-gradient { background: linear-gradient(135deg, #1e3a8a, #3b82f6, #60a5fa); }
    .nav-link { position: relative; transition: 0.3s; color: white; font-weight: 600; }

    .nav-link:hover::after { transform: translateX(-50%) scaleX(1); }
    .nav-link::after {
        content: ''; position: absolute; bottom: -4px; left: 50%; width: 70%; height: 2px;
        background: yellow; border-radius: 2px; transform: translateX(-50%) scaleX(0); transition: transform 0.3s;
    }
    
  
    .nav-link.active-link { color: #facc15;  }
    .nav-link.active-link::after { transform: translateX(-50%) scaleX(1); }

    .mobile-menu { max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; }
    .mobile-menu.active { max-height: 500px; }
</style>
</head>
<body class="flex flex-col min-h-screen">

<header class="hero-gradient text-white sticky top-0 z-50 shadow">
  <div class="container mx-auto px-4 py-4 flex justify-between items-center">
    <a href="/" class="flex items-center space-x-3">
      <img src="/images/logo mkw.png" alt="Logo Manokwari" class="h-14 w-14 rounded-full bg-white/20 p-1">
      <div>
        <h1 class="text-2xl md:text-3xl font-bold">Eksplor Manokwari</h1>
        <p class="text-xs text-yellow-200">Gerbang Surga Papua Barat</p>
      </div>
    </a>

    <nav class="hidden md:block">
      <ul class="flex space-x-6" id="desktop-nav-links">
        <li><a href="/" class="nav-link">Home</a></li>
        <li><a href="/tentang" class="nav-link">Tentang Kota</a></li>
        <li><a href="/destinasi" class="nav-link">Destinasi</a></li>
        <li><a href="/kuliner" class="nav-link">Kuliner</a></li>
        <li><a href="/galeri" class="nav-link">Galeri</a></li>
        <li><a href="/kontak" class="nav-link">Kontak</a></li>
        <li><a href="/peta" class="nav-link">Peta Wisata</a></li>
      </ul>
    </nav>

    <button id="mobile-menu-btn" class="md:hidden p-2 rounded-lg hover:bg-white/20">
      <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
      </svg>
    </button>
  </div>

  <div id="mobile-menu" class="mobile-menu md:hidden mt-2">
    <ul class="flex flex-col space-y-2 bg-white/10 backdrop-blur-md rounded-lg p-4" id="mobile-nav-links">
      <li><a href="/" class="block px-3 py-2 rounded hover:bg-white/20">Home</a></li>
      <li><a href="/tentang" class="block px-3 py-2 rounded hover:bg-white/20">Tentang Kota</a></li>
      <li><a href="/destinasi" class="block px-3 py-2 rounded hover:bg-white/20">Destinasi</a></li>
      <li><a href="/kuliner" class="block px-3 py-2 rounded hover:bg-white/20">Kuliner</a></li>
      <li><a href="/galeri" class="block px-3 py-2 rounded hover:bg-white/20">Galeri</a></li>
      <li><a href="/kontak" class="block px-3 py-2 rounded hover:bg-white/20">Kontak</a></li>
      <li><a href="/peta" class="block px-3 py-2 rounded hover:bg-white/20">Peta Wisata</a></li>
    </ul>
  </div>
</header>

<main class="flex-grow">
    @yield('content')
</main>

<footer class="relative bg-gradient-to-br from-blue-900 via-blue-700 to-blue-600 text-white mt-8">
    <div class="max-w-5xl mx-auto px-4 py-8 text-center">
        <div class="border-t border-white/20 pt-6">
            <p class="text-base leading-tight">
                &copy; {{ date('Y') }} <span class="font-semibold text-yellow-300">Eksplor Manokwari</span> - Papua Barat.
            </p>
            <p class="text-sm text-blue-100 mt-3">
                Dibuat dengan <span class="text-red-400">Cinta</span> oleh <span class="font-semibold text-yellow-300">Angel</span> untuk <span class="font-semibold text-yellow-300">Manokwari Tercinta</span>.
            </p>
        </div>
    </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('mobile-menu-btn');
    const menu = document.getElementById('mobile-menu');
    btn.addEventListener('click', () => menu.classList.toggle('active'));
    const currentPath = window.location.pathname.replace(/\/+$/, ""); 
    
    function setActiveLink(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const links = container.querySelectorAll('a');
        links.forEach(link => {
            const linkPath = link.getAttribute('href').replace(/\/+$/, "");

            if (currentPath === linkPath) {
                if (containerId === 'desktop-nav-links') {
                    link.classList.add('active-link');
                } 

                else if (containerId === 'mobile-nav-links') {
                    link.classList.remove('hover:bg-white/20');
                    link.classList.add('bg-white/20', 'text-yellow-300');
                }
            }
        });
    }

    setActiveLink('desktop-nav-links');
    setActiveLink('mobile-nav-links');
});
</script>

</body>
</html>