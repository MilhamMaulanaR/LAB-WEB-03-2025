@props(['image', 'title', 'description'])

<div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-2xl transition duration-300 transform hover:-translate-y-2">
    <img src="{{ $image }}" alt="{{ $title }}" class="w-full h-80 object-cover">
    <div class="p-6">
        <h3 class="text-xl font-bold text-blue-900 mb-3">{{ $title }}</h3>
        <p class="text-gray-600 leading-relaxed">{{ $description }}</p>
    </div>
</div>
