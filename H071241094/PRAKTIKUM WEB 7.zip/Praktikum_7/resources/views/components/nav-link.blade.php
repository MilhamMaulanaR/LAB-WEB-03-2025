@props(['href' => '#', 'active' => false, 'mobile' => false])

@php
    if ($mobile) {
        // Gaya untuk Mobile Menu (di dalam div/ul mobile-menu)
        $classes = 'block px-3 py-2 rounded transition-colors duration-200';
        
        if ($active) {
            // Tautan Aktif Mobile: Teks kuning dan background
            $classes .= ' bg-white/20 text-yellow-300';
        } else {
            // Tautan Normal Mobile: Hanya hover background
            $classes .= ' hover:bg-white/20 text-white';
        }
    } else {
        // Gaya untuk Desktop Menu (dengan efek garis bawah CSS)
        $classes = 'nav-link';

        if ($active) {
            // Tautan Aktif Desktop: Class CSS 'active-link'
            $classes .= ' active-link';
        }
        // Tautan Desktop secara default memiliki text-white (dari header)
    }
@endphp

<a href="{{ $href }}" {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>