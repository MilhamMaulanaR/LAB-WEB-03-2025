@extends('layouts.master')

@section('title', 'Home - Eksplor Manokwari')

@section('content')
<style>
@keyframes slideInRight {
  0% { opacity: 0; transform: translateX(80px); }
  100% { opacity: 1; transform: translateX(0); }
}

@keyframes slideInLeft {
  0% { opacity: 0; transform: translateX(-80px); }
  100% { opacity: 1; transform: translateX(0); }
}

@keyframes fadeInSlow {
  0% { opacity: 0; transform: scale(0.9); }
  100% { opacity: 1; transform: scale(1); }
}

@keyframes bgMove {
  0% { transform: scale(1) translateY(0px); }
  50% { transform: scale(1.05) translateY(-15px); }
  100% { transform: scale(1) translateY(0px); }
}

.animate-slide-right {
  animation: slideInRight 1.2s ease-out forwards;
}
.animate-slide-left {
  animation: slideInLeft 1.2s ease-out forwards;
}
.animate-fade-slow {
  animation: fadeInSlow 1.8s ease-in-out forwards;
}
.animate-bg {
  animation: bgMove 10s ease-in-out infinite alternate;
}
</style>

<!-- Hero Section Fullscreen -->
<div class="relative w-full h-screen overflow-hidden">
    <img src="{{ asset('images/bg.png') }}" 
         alt="Pemandangan Manokwari" 
         class="absolute inset-0 w-full h-full object-cover object-center animate-bg">


    <div class="absolute inset-0 flex flex-col justify-center items-center text-center text-white px-6 transform -translate-y-[4.5rem]">
        <h2 class="text-5xl font-extrabold mb-4 drop-shadow-lg opacity-0 animate-slide-right">
            Selamat Datang di Manokwari
        </h2>
        <p class="text-2xl font-light drop-shadow-md opacity-0 animate-slide-left [animation-delay:0.5s]">
            Gerbang Surga di Ujung Timur Indonesia
        </p>

        <a href="/destinasi"
           class="mt-8 bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg text-lg font-semibold shadow-lg transition 
                  opacity-0 animate-fade-slow [animation-delay:1.2s]">
           Jelajahi Destinasi
        </a>
    </div>
</div>
@endsection
