<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['href' => '#', 'variant' => 'primary']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href' => '#', 'variant' => 'primary']); ?>
<?php foreach (array_filter((['href' => '#', 'variant' => 'primary']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $classes = $variant === 'primary' 
        ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl' 
        : 'bg-white hover:bg-gray-50 text-gray-800 border-2 border-gray-300 hover:border-purple-600';
?>

<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => "inline-flex items-center px-8 py-4 rounded-full font-bold transition-all duration-300 transform hover:scale-105 btn-glow $classes"])); ?>>
    <?php echo e($slot); ?>

    <svg class="w-5 h-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
    </svg>
</a><?php /**PATH C:\xampp\htdocs\Praktikum_7\resources\views/components/button.blade.php ENDPATH**/ ?>