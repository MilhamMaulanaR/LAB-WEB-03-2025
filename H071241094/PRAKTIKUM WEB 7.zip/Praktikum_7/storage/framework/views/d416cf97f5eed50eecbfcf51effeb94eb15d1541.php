


<?php $__env->startSection('title', 'Tentang Kota - Eksplor Manokwari'); ?>

<?php $__env->startSection('content'); ?>
<style>
    @keyframes fadeInUp { from {opacity:0; transform:translateY(40px);} to {opacity:1; transform:translateY(0);} }
    @keyframes fadeInLeft { from {opacity:0; transform:translateX(-60px);} to {opacity:1; transform:translateX(0);} }
    @keyframes fadeInRight { from {opacity:0; transform:translateX(60px);} to {opacity:1; transform:translateX(0);} }

    .animate-fadeInUp { animation: fadeInUp 1s ease-out forwards; }
    .animate-fadeInLeft { animation: fadeInLeft 1s ease-out forwards; }
    .animate-fadeInRight { animation: fadeInRight 1s ease-out forwards; }

    .delay-200 { animation-delay: .2s; }
    .delay-400 { animation-delay: .4s; }
    .delay-600 { animation-delay: .6s; }
    .delay-800 { animation-delay: .8s; }
    .delay-1000 { animation-delay: 1s; }

    .gradient-text {
        background: linear-gradient(135deg, #1e3a8a, #3b82f6, #1e3a8a);
        background-size: 200% 200%;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: shimmer 3s linear infinite;
    }
    @keyframes shimmer {
        0%,100% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
    }

  
    .image-hover { transition: all .5s cubic-bezier(.175,.885,.32,1.275); }
    .image-hover:hover { transform: scale(1.05) rotate(1deg); box-shadow: 0 20px 40px -10px rgba(0,0,0,.3); }

    .glass-card {
        background: rgba(255,255,255,.9);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,.3);
    }

    .section-bg {
        background-image: radial-gradient(circle at 20% 50%, rgba(30,58,138,.05) 0%, transparent 50%),
                          radial-gradient(circle at 80% 80%, rgba(59,130,246,.05) 0%, transparent 50%);
    }

    .logo-float { filter: drop-shadow(0 8px 20px rgba(0,0,0,.15)); animation: float 3s ease-in-out infinite; }
    @keyframes float { 0%,100% { transform:translateY(0);} 50% { transform:translateY(-12px);} }
</style>

<!--Hero Section -->
<div class="text-center mb-20 mt-16 section-bg py-12">
    <div class="opacity-0 animate-fadeInUp">
        <img src="<?php echo e(asset('images/logo mkw.png')); ?>" alt="logo mkw" class="w-32 h-32 md:w-40 md:h-40 mx-auto mb-6 logo-float">
        <h2 class="text-6xl md:text-7xl font-black gradient-text mb-6">Tentang Kota Manokwari</h2>
        <p class="text-xl md:text-2xl text-gray-700 max-w-4xl mx-auto leading-relaxed px-4">
            Manokwari, ibu kota Provinsi Papua Barat, dikenal sebagai <span class="font-bold text-blue-700">Kota Injil</span> dan memiliki sejarah panjang serta keindahan alam yang mempesona. 
            Terletak di <span class="font-bold text-blue-700">Teluk Doreri</span>, kota ini menjadi pusat pemerintahan, budaya, dan pendidikan di wilayah Papua Barat.
        </p>
        <div class="flex justify-center gap-2 mt-6">
            <span class="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"></span>
            <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse"></span>
            <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse delay-200"></span>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="max-w-6xl mx-auto mb-20 px-4">

    <!-- Sejarah -->
    <div class="grid md:grid-cols-2 gap-12 items-center mb-20 opacity-0 animate-fadeInLeft delay-200">
        <div class="glass-card p-8 rounded-3xl shadow-2xl">
            <h3 class="text-3xl font-black text-blue-900 mb-6">Sejarah & Identitas</h3>
           <p class="text-gray-700 leading-relaxed text-lg mb-4">
                   Manokwari, ibu kota Papua Barat, dikenal sebagai Kota Injil karena menjadi pusat penyebaran Kristen di Papua sejak 1855. Kota ini juga disebut Kota Peradaban Orang Papua, mencerminkan interaksi antara masyarakat lokal dan misionaris Eropa. Berada di wilayah dataran rendah, perbukitan, dan pegunungan, Manokwari berbatasan dengan Samudera Pasifik di utara dan Kabupaten Teluk Wondama di timur. Sejarah dan identitasnya mencerminkan kekayaan budaya, tradisi lokal, serta peran penting dalam pembangunan Papua Barat.
                </p>
        </div>
        <img src="<?php echo e(asset('images/pmkw.png')); ?>" alt="Kota Manokwari" class="rounded-3xl shadow-2xl w-full h-[500px] object-cover image-hover opacity-0 animate-fadeInRight delay-400">
    </div>

    <!-- Judul Budaya -->
    <div class="text-center mb-16 opacity-0 animate-fadeInUp delay-600">
        <div class="flex items-center justify-center gap-4 mb-6">
            <div class="h-1 w-20 bg-gradient-to-r from-transparent to-blue-600 rounded-full"></div>
            <h3 class="text-4xl md:text-5xl font-black text-gray-800">Kekayaan Budaya</h3>
            <div class="h-1 w-20 bg-gradient-to-l from-transparent to-blue-600 rounded-full"></div>
        </div>
        <p class="text-xl text-gray-600 max-w-3xl mx-auto">Jelajahi warisan budaya yang kaya dan tradisi yang masih terjaga hingga kini</p>
    </div>

    <!-- Rumah Adat -->
    <div class="grid md:grid-cols-2 gap-12 items-center mb-20 opacity-0 animate-fadeInRight delay-800">
        <img src="<?php echo e(asset('images/rumah adat.png')); ?>" alt="Rumah Adat Papua" class="rounded-3xl shadow-2xl w-full h-[450px] object-cover image-hover opacity-0 animate-fadeInLeft delay-1000">
        <div class="glass-card p-8 rounded-3xl shadow-2xl">
            <h3 class="text-3xl font-black text-blue-900 mb-6">Rumah Kaki Seribu</h3>
           <p class="text-gray-700 leading-relaxed text-lg mb-4">Rumah Kaki Seribu, atau Mod Aki Aksa dalam bahasa Meyah, adalah rumah adat tradisional suku Arfak yang terletak di Kabupaten Manokwari, Papua Barat. Rumah ini dikenal karena banyaknya tiang penyangga yang terletak di bawahnya, sehingga memiliki banyak kaki. Atap rumah ini biasanya terbuat dari daun jerami atau daun sagu, dan tiangnya terbuat dari kayu. Rumah ini memiliki fungsi untuk melindungi penduduk dari serangan musuh dan ancaman ilmu hitam. Desain rumah ini juga tidak memiliki jendela untuk menjaga suhu dalam rumah tetap hangat. Rumah Kaki Seribu umumnya dipakai oleh penduduk yang tinggal di daerah pegunungan dan berhawa dingin.
            </p>
        </div>
    </div>

    <!-- Tarian Adat -->
    <div class="grid md:grid-cols-2 gap-12 items-center mb-20 opacity-0 animate-fadeInLeft delay-1000">
        <div class="glass-card p-8 rounded-3xl shadow-2xl">
            <h3 class="text-3xl font-black text-blue-900 mb-6">Tari Tumbu Tanah</h3>
           <p class="text-gray-700 leading-relaxed text-lg mb-4">Tari Tumbu Tanah adalah tarian tradisional khas masyarakat Suku Arfak di Manokwari, yang melambangkan identitas budaya dan sering dipentaskan dalam berbagai acara penting. Tari Tumbu Tanah merupakan tarian yang dilakukan oleh masyarakat Suku Arfak yang tinggal di Manokwari, Papua Barat. Tarian ini biasanya melibatkan lebih dari sepuluh penari dan sering dipentaskan untuk menyambut tamu, merayakan kemenangan, serta dalam acara resepsi pernikahan dan perayaan besar lainnya.
            </p>
        </div>
        <img src="<?php echo e(asset('images/tarian.png')); ?>" alt="Tarian Adat Papua" class="rounded-3xl shadow-2xl w-full h-[450px] object-cover image-hover opacity-0 animate-fadeInRight delay-1000">
    </div>

    <!-- Tradisi -->
    <div class="grid md:grid-cols-2 gap-12 items-center mb-20 opacity-0 animate-fadeInRight delay-1000">
        <img src="<?php echo e(asset('images/bakar batu.png')); ?>" alt="Tradisi Adat Papua" class="rounded-3xl shadow-2xl w-full h-[450px] object-cover image-hover opacity-0 animate-fadeInLeft delay-1000">
         <div class="glass-card p-8 rounded-3xl shadow-2xl">
            <h3 class="text-3xl font-black text-blue-900 mb-6 flex items-center gap-3">
                Tradisi Bakar Batu
            </h3>
            <p class="text-gray-700 leading-relaxed text-lg mb-4">Tradisi Bakar Batu di Manokwari, Papua Barat, merupakan ritual adat untuk memasak bersama menggunakan batu panas.
Acara ini dilakukan sebagai bentuk syukur, perayaan, atau penyambutan tamu penting.
Bahan seperti daging, sayuran, dan umbi-umbian dimasak bersama di atas tumpukan batu membara.
Prosesnya melibatkan kerja sama seluruh warga, mencerminkan semangat gotong royong dan persatuan.
Selain bermakna sosial, tradisi ini juga menjadi simbol penghormatan kepada leluhur.
Kini, bakar batu dilestarikan sebagai warisan budaya dan daya tarik wisata khas Papua Barat.
            </p>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_7\resources\views/tentang.blade.php ENDPATH**/ ?>