<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['href' => '#', 'active' => false, 'mobile' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href' => '#', 'active' => false, 'mobile' => false]); ?>
<?php foreach (array_filter((['href' => '#', 'active' => false, 'mobile' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    if ($mobile) {
        // Gaya untuk Mobile Menu (di dalam div/ul mobile-menu)
        $classes = 'block px-3 py-2 rounded transition-colors duration-200';
        
        if ($active) {
            // Tautan Aktif Mobile: Teks kuning dan background
            $classes .= ' bg-white/20 text-yellow-300';
        } else {
            // Tautan Normal Mobile: Hanya hover background
            $classes .= ' hover:bg-white/20 text-white';
        }
    } else {
        // Gaya untuk Desktop Menu (dengan efek garis bawah CSS)
        $classes = 'nav-link';

        if ($active) {
            // Tautan Aktif Desktop: Class CSS 'active-link'
            $classes .= ' active-link';
        }
        // Tautan Desktop secara default memiliki text-white (dari header)
    }
?>

<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH C:\xampp\htdocs\Praktikum_7\resources\views/components/nav-link.blade.php ENDPATH**/ ?>