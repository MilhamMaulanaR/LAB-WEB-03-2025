

<?php $__env->startSection('title', 'Destinasi - Eksplor Manokwari'); ?>

<?php $__env->startSection('content'); ?>
<style>
    /* Animasi */

@keyframes fadeInUp { from {opacity:0; transform:translateY(30px);} to {opacity:1; transform:translateY(0);} }
@keyframes fadeInDown { from {opacity:0; transform:translateY(-30px);} to {opacity:1; transform:translateY(0);} }
@keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }

.animate-fadeInUp { animation: fadeInUp 0.8s ease-out forwards; }
.animate-fadeInDown { animation: fadeInDown 0.8s ease-out forwards; }
.animate-float { animation: float 3s ease-in-out infinite; }


.gradient-text {
    background: linear-gradient(135deg, #1e40af, #3b82f6, #60a5fa);
    background-size: 200% 200%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: shimmer 3s linear infinite;
}

@keyframes shimmer {
    0% { background-position: -1000px 0; }
    100% { background-position: 1000px 0; }
}

    @keyframes fadeInDown { from {opacity:0; transform:translateY(-40px);} to {opacity:1; transform:translateY(0);} }
    @keyframes slideInLeft { from {opacity:0; transform:translateX(-60px);} to {opacity:1; transform:translateX(0);} }
    @keyframes slideInRight { from {opacity:0; transform:translateX(60px);} to {opacity:1; transform:translateX(0);} }

    .animate-fadeInDown { animation: fadeInDown 0.8s ease-out forwards; }
    .animate-slideInLeft { animation: slideInLeft 0.8s ease-out forwards; }
    .animate-slideInRight { animation: slideInRight 0.8s ease-out forwards; }

    .delay-300{animation-delay:.3s} .delay-400{animation-delay:.4s}
    .delay-500{animation-delay:.5s} .delay-600{animation-delay:.6s}
    .delay-700{animation-delay:.7s} .delay-800{animation-delay:.8s}
    .delay-900{animation-delay:.9s} .delay-1000{animation-delay:1s}

    .card-wrapper { transition: transform .4s cubic-bezier(.175,.885,.32,1.275); }
    .card-wrapper:hover { transform: translateY(-10px) scale(1.02); }

    .parallax-bg {
        background-image: radial-gradient(circle at 20% 30%,rgba(59,130,246,.08)0%,transparent 50%),
                          radial-gradient(circle at 80% 70%,rgba(96,165,250,.08)0%,transparent 50%);
    }
</style>

<!-- Hero Section -->
<div class="relative mb-15 parallax-bg text-center py-16">
    <h2 class="text-5xl md:text-7xl font-black gradient-text mb-6 animate-fadeInDown">
       Destinasi Wisata Manokwari
    </h2>
    <p class="text-2xl md:text-3xl text-gray-700 font-semibold animate-fadeInUp delay-200 mb-6">
        Jelajahi Keindahan Alam Papua Barat
    </p>
    <div class="flex justify-center gap-2 animate-fadeInUp delay-300">
        <span class="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse delay-100"></span>
    </div>
</div>


<!-- Destinasi Section -->
<div class="max-w-7xl mx-auto px-4 mb-20 grid grid-cols-1 md:grid-cols-2 gap-8">

    <div class="opacity-0 animate-slideInLeft delay-300 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/pantai pasir putih.png','title' => 'Pantai Pasir Putih','description' => 'Pantai dengan pasir putih yang lembut dan air laut biru jernih. Tempat sempurna untuk snorkeling dan menikmati sunset yang memukau di Teluk Doreri.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/pantai pasir putih.png','title' => 'Pantai Pasir Putih','description' => 'Pantai dengan pasir putih yang lembut dan air laut biru jernih. Tempat sempurna untuk snorkeling dan menikmati sunset yang memukau di Teluk Doreri.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInRight delay-400 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/mansinam.png','title' => 'Pulau Mansinam','description' => 'Pulau bersejarah tempat pendaratan misionaris pertama di Papua. Dikelilingi pantai indah dan terumbu karang alami.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/mansinam.png','title' => 'Pulau Mansinam','description' => 'Pulau bersejarah tempat pendaratan misionaris pertama di Papua. Dikelilingi pantai indah dan terumbu karang alami.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInLeft delay-500 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/pantai bakaro.png','title' => 'Pantai Bakaro','description' => 'Pantai yang terkenal dengan tradisi unik \'memanggil ikan\'. Air lautnya jernih dan suasananya alami.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/pantai bakaro.png','title' => 'Pantai Bakaro','description' => 'Pantai yang terkenal dengan tradisi unik \'memanggil ikan\'. Air lautnya jernih dan suasananya alami.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInRight delay-600 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/pantai amban.png','title' => 'Pantai Amban','description' => 'Pantai alami dan tenang di Kelurahan Amban, cocok untuk wisatawan yang ingin bersantai jauh dari keramaian.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/pantai amban.png','title' => 'Pantai Amban','description' => 'Pantai alami dan tenang di Kelurahan Amban, cocok untuk wisatawan yang ingin bersantai jauh dari keramaian.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInLeft delay-700 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/pantai sidey.png','title' => 'Pantai Sidey','description' => 'Pantai dengan panorama indah dan kegiatan budaya seperti lomba perahu dan ekowisata lokal.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/pantai sidey.png','title' => 'Pantai Sidey','description' => 'Pantai dengan panorama indah dan kegiatan budaya seperti lomba perahu dan ekowisata lokal.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInRight delay-800 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/danau anggi.png','title' => 'Danau Anggi Giji & Gita','description' => 'Dua danau kembar yang menyimpan legenda cinta suku Arfak, dengan panorama pegunungan yang menakjubkan.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/danau anggi.png','title' => 'Danau Anggi Giji & Gita','description' => 'Dua danau kembar yang menyimpan legenda cinta suku Arfak, dengan panorama pegunungan yang menakjubkan.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInLeft delay-900 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/gunung meja.png','title' => 'Gunung Meja','description' => 'Gunung dengan puncak datar di pusat kota Manokwari, populer untuk hiking dan piknik.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/gunung meja.png','title' => 'Gunung Meja','description' => 'Gunung dengan puncak datar di pusat kota Manokwari, populer untuk hiking dan piknik.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="opacity-0 animate-slideInRight delay-1000 card-wrapper">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['image' => '/images/gunung botak.png','title' => 'Gunung Botak','description' => 'Gunung dengan pemandangan laut dan bukit hijau kekuningan, cocok untuk trekking dan camping.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => '/images/gunung botak.png','title' => 'Gunung Botak','description' => 'Gunung dengan pemandangan laut dan bukit hijau kekuningan, cocok untuk trekking dan camping.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_7\resources\views/destinasi.blade.php ENDPATH**/ ?>