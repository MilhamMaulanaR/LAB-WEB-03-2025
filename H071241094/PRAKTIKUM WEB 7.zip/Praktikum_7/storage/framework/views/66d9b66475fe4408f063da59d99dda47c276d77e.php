

<?php $__env->startSection('title', 'Galeri - Eksplor Manokwari'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $galeri = [
        ['images/pantai amban.png', 'Pantai Amban', 'Destinasi', 'gray'],
        ['images/pegaf.png', 'Pegunungan Arfak', 'Kamera Saya', 'gray'],
        ['images/anggi.png', 'Danau Anggi Giji & Gita', 'Destinasi', 'gray'],
        ['images/gunung meja.png', 'Gunung Meja', 'Destinasi', 'gray'],
        ['images/pantai pasir putih.png', 'Pantai Pasir Putih', 'Destinasi', 'gray'],
        ['images/mansinam.png', 'Pulau Mansinam', 'Destinasi', 'gray'],
        ['images/gunung botak.png', 'Gunung Botak', 'Destinasi', 'gray'],
        ['images/pantai sidey.png', 'Pantai Sidey', 'Destinasi', 'gray'],
        ['images/pantai bakaro.png', 'Pantai Bakaro', 'Destinasi', 'gray'],
        ['images/pulau mansinam.png', 'Pulau Mansinam', 'Kamera Saya', 'gray'],
        ['images/rumah adat.png', 'Rumah Kaki Seribu', 'Tentang Kota', 'gray'],
        ['images/tarian.png', 'Tari Tumbu Tanah', 'Tentang Kota', 'gray'],
        ['images/bakar batu.png', 'Tradisi Bakar Batu', 'Tentang Kota', 'gray'],
        ['images/papeda.png', 'Papeda', 'Kuliner', 'gray'],
        ['images/ikan bakar.png', 'Ikan Bakar', 'Kuliner', 'gray'],
        ['images/udang.png', 'Udang Selingkuh', 'Kuliner', 'gray'],
        ['images/abon gulung.png', 'Abon Gulung', 'Kuliner', 'gray'],
        ['images/Buah Merah.png', 'Buah Merah', 'Kuliner', 'gray'],
        ['images/sagu lempeng.png', 'Sagu Lempeng', 'Kuliner', 'gray'],
        ['images/soribo.png', 'Tongkonan Soribo', 'Kota', 'gray'],
        ['images/taman jokowi.png', 'Taman Jokowi', 'Kamera Saya', 'gray'],
        ['images/batik.png', 'Batik Papua', 'Pribadi', 'gray'],
        ['images/teluk doreri.png', 'Suasana Kota di Senja', 'Pribadi', 'gray'],
    ];
?>

<style>
@keyframes fadeInUp { from {opacity:0; transform:translateY(30px);} to {opacity:1; transform:translateY(0);} }
@keyframes fadeInDown { from {opacity:0; transform:translateY(-30px);} to {opacity:1; transform:translateY(0);} }
@keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-15px);} }
@keyframes scaleIn { from {opacity:0; transform:scale(0.9);} to {opacity:1; transform:scale(1);} }

.animate-fadeInUp { animation: fadeInUp 0.8s ease-out both; }
.animate-fadeInDown { animation: fadeInDown 0.8s ease-out both; }
.animate-float { animation: float 3s ease-in-out infinite; }


.gallery-item {
    animation: scaleIn 0.7s ease-out both;
}
.gallery-item:nth-child(odd) { animation-delay: 0.1s; }
.gallery-item:nth-child(even) { animation-delay: 0.2s; }
</style>

<!-- HERO SECTION -->
<div class="relative mb-15 parallax-bg text-center py-16">
    <h2 class="text-5xl md:text-7xl font-extrabold text-blue-700 mb-4 animate-fadeInDown">
        Galeri Manokwari
    </h2>
    <p class="text-xl md:text-2xl text-gray-700 font-medium animate-fadeInUp delay-200 mb-6">
        Temukan hal-hal indah di Manokwari melalui galeri kami.
    </p>
    <div class="flex justify-center gap-2 animate-fadeInUp delay-300">
        <span class="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse"></span>
        <span class="w-4 h-1.5 bg-blue-300 rounded-full animate-pulse delay-100"></span>
    </div>
</div>


<div class="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-5 px-6 mb-16 space-y-5">
    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="gallery-item relative overflow-hidden rounded-xl shadow-md mb-5 break-inside-avoid group">
            <img src="<?php echo e(asset($item[0])); ?>" alt="<?php echo e($item[1]); ?>" 
                 class="w-full rounded-lg object-cover transition duration-500 transform group-hover:scale-110">
            <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition duration-500 flex flex-col justify-end p-4">
                <p class="text-white font-semibold text-lg"><?php echo e($item[1]); ?></p>
                <span class="text-xs text-gray-200 font-medium bg-black/50 px-2 py-0.5 rounded self-start mt-1">
                    <?php echo e($item[2]); ?>

                </span>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="bg-gradient-to-r from-blue-50 to-indigo-50 p-8 rounded-lg text-center mx-6 md:mx-20 mb-16 shadow-md animate-fadeInUp">
    <h3 class="text-2xl font-bold text-blue-900 mb-3">Bagikan Momen Anda!</h3>
    <p class="text-gray-700 mb-3">Punya foto menarik dari Manokwari? Bagikan dengan kami!</p>
    <p class="text-sm text-gray-600">
        Gunakan hashtag <span class="font-bold text-blue-600">#EksplorManokwari</span> di media sosial Anda.
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_7\resources\views/galeri.blade.php ENDPATH**/ ?>