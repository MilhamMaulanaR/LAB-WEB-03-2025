@extends('layouts.app')

@section('extra-class', 'transparent-mode')
@section('title', 'Edit Ikan')

@section('content')
<div class="fish-form-container mx-auto p-4">
    <h3 class="mb-4 text-center fw-bold text-primary">Edit Ikan</h3>

    <form action="{{ route('fishes.update', $fish) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Nama Ikan</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $fish->name) }}">
            @error('name')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="mb-3">
            <label>Rarity</label>
            <select name="rarity" class="form-select">
                @foreach($rarities as $r)
                    <option value="{{ $r }}" {{ old('rarity', $fish->rarity) == $r ? 'selected' : '' }}>
                        {{ $r }}
                    </option>
                @endforeach
            </select>
            @error('rarity')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Berat Minimum (kg)</label>
                <input type="number" step="0.01" name="base_weight_min" class="form-control"
                       min="0.1" max="100" value="{{ old('base_weight_min', $fish->base_weight_min) }}" required>
                @error('base_weight_min')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
            <div class="col-md-6 mb-3">
                <label>Berat Maksimum (kg)</label>
                <input type="number" step="0.01" name="base_weight_max" class="form-control"
                       min="0.1" max="100" value="{{ old('base_weight_max', $fish->base_weight_max) }}" required>
                @error('base_weight_max')<small class="text-danger">{{ $message }}</small>@enderror
            </div>
        </div>

        <div class="mb-3">
            <label>Harga Jual per Kg (Coins)</label>
            <input type="number" name="sell_price_per_kg" class="form-control"
                   value="{{ old('sell_price_per_kg', $fish->sell_price_per_kg) }}">
            @error('sell_price_per_kg')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="mb-3">
            <label>Catch Probability (%)</label>
            <input type="number" step="0.01" name="catch_probability" class="form-control"
                   min="0.01" max="100" value="{{ old('catch_probability', $fish->catch_probability) }}" required>
            @error('catch_probability')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control" rows="4">{{ old('description', $fish->description) }}</textarea>
            @error('description')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="text-center mt-4">
            <button class="btn btn-primary px-4 me-2">Update</button>
            <a href="{{ route('fishes.index') }}" class="btn btn-outline-secondary px-4">Batal</a>
        </div>
    </form>
</div>

<style>
    body {
        background: url('{{ asset('image/bg.png') }}') center/cover no-repeat;
        font-family: "Poppins", sans-serif;
    }

    .transparent-mode {
        background: rgba(255,255,255,0.3);
        backdrop-filter: blur(10px);
    }

    .fish-form-container {
        max-width: 600px;
        background: rgba(255,255,255,0.35);
        backdrop-filter: blur(15px);
        padding: 2rem;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        margin: 60px auto;
        transition: 0.3s;
    }

    .fish-form-container:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }

    label {
        font-weight: 600;
        color: #0b3954;
    }

    input, textarea, select {
        border-radius: 10px;
        border: 1px solid rgba(0,0,0,0.1);
    }

    .btn-primary {
        background-color: #1e88e5;
        border: none;
        color: #fff;
    }
    .btn-primary:hover { background-color: #1565c0; }

    .btn-outline-secondary {
        background-color: rgba(255,255,255,0.3);
        border: 1px solid rgba(255,255,255,0.5);
        color: #0a3d62;
    }
    .btn-outline-secondary:hover { background-color: rgba(255,255,255,0.5); }
</style>
@endsection
