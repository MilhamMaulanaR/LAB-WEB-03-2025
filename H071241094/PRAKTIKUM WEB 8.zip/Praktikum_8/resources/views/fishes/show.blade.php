@extends('layouts.app')

@section('extra-class', 'transparent-mode')
@section('title', 'Daftar Ikan')

@section('content')
@php
    $minWeight = $maxWeight = '-';
    if (!empty($fish->weight_range)) {
        preg_match_all('/\d+(\.\d+)?/', $fish->weight_range, $matches);
        if(count($matches[0]) >= 2){
            $minWeight = $matches[0][0] . ' kg';
            $maxWeight = $matches[0][1] . ' kg';
        }
    }
@endphp

<div class="card fish-detail mx-auto p-4" style="max-width:600px;">
    @foreach([
        'Nama Ikan' => $fish->name,
        'Rarity' => $fish->rarity,
        'Berat Minimum' => $minWeight,
        'Berat Maksimum' => $maxWeight,
        'Rentang Berat' => $fish->weight_range ?? '-',
        'Harga per Kg' => $fish->formatted_price ?? '-',
        'Peluang Tertangkap' => $fish->catch_probability ? $fish->catch_probability.'%' : '-',
        'Deskripsi' => $fish->description ?: 'Belum ada deskripsi.',
        'Waktu Dibuat' => $fish->created_at,
        'Terakhir Diperbarui' => $fish->updated_at
    ] as $label => $value)
        <div class="fish-item mb-2"><strong>{{ $label }}</strong><span>{{ $value }}</span></div>
    @endforeach

    <div class="text-center mt-4">
        <a href="{{ route('fishes.edit', $fish) }}" class="btn btn-warning px-4 me-2">Edit</a>
        <a href="{{ route('fishes.index') }}" class="btn btn-secondary px-4">Kembali</a>
    </div>
</div>

<style>
    body {
        font-family: "Poppins", sans-serif;
        min-height: 100vh;
        margin: 0;
        background: url('{{ asset('image/bg.png') }}') center/cover no-repeat fixed;
    }

    .fish-detail {
        background: rgba(255,255,255,0.35);
        border: 1px solid rgba(255,255,255,0.25);
        backdrop-filter: blur(15px);
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        transition: all 0.3s ease;
    }
    .fish-detail:hover { transform: translateY(-4px); box-shadow: 0 10px 25px rgba(0,0,0,0.2); }

    .fish-item {
        display: flex;
        gap: 10px;
        padding: 10px 15px;
        border-bottom: 1px solid rgba(255,255,255,0.2);
    }
    .fish-item:last-child { border-bottom: none; }
    .fish-item strong { width: 180px; color: #0b3954; font-weight: 600; }
    .fish-item span { flex: 1; color: #093a5d; font-weight: 500; }

    .btn-warning { color: #fff; background-color: #1e88e5; border: none; font-weight: 500; }
    .btn-warning:hover { background-color: #1565c0; }
    .btn-secondary { background-color: rgba(255,255,255,0.3); color:#083358; border:1px solid rgba(255,255,255,0.5); }
    .btn-secondary:hover { background-color: rgba(255,255,255,0.5); }
</style>
@endsection
