<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title','Fish It Manager'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>      
body {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    margin: 0;
    font-family: 'Poppins', sans-serif;
    color: #0b2948;
    background: linear-gradient(180deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%);
    background-attachment: fixed;
    padding-top: 56px;
    padding-bottom: 50px; 
}

.container.main-content {
    width: 100%;
    max-width: none;
    margin: 0;
}

    .container.main-content {
    flex: 1;
    background: rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(8px);
    border-radius: 20px;
    padding: 2rem;
    margin: 2rem auto; 
    width: 90%;
    max-width: 1100px;
    box-shadow: 0 20px 50px rgba(14, 165, 233, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
}
.navbar-collapse {
    background: rgba(14,165,233,0.95);
    border-radius: 10px;
    margin-top: 10px;
    padding: 10px 0;
}
.bubbles {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    z-index: -1;
}

:root {
    --ocean-light: #e0f2fe;
    --ocean-blue: #0ea5e9;
    --ocean-deep: #0369a1;
    --ocean-dark: #075985;
    --wave-color: #bae6fd;
}
body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    background: linear-gradient(180deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%);
    background-attachment: fixed;
    
    padding-top: 50px; 
    padding-bottom: 40px; 
}

.navbar {
    height: 56px;
    background: linear-gradient(135deg, rgba(14,165,233,0.9), rgba(2,132,199,0.9)) !important;
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    box-shadow: 0 4px 16px rgba(14, 165, 233, 0.25);
    z-index: 1000;
}
.container-custom {
    width: 100%;
    padding-right: var(--bs-gutter-x,.75rem);
    padding-left: var(--bs-gutter-x,.75rem);
    margin-right: auto;
    margin-left: auto;
    max-width: 1200px; 
}

.navbar-brand {
    font-weight: 700;
    font-size: 1.4rem;
    color: #fff !important;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
}
.navbar-brand:hover {
    color: #e0f2fe !important;
}
.navbar-brand i {
    animation: swim 3s ease-in-out infinite;
}

.nav-link {
    color: rgba(255, 255, 255, 0.9) !important;
    font-weight: 500;
    padding: 6px 14px !important;
    border-radius: 8px;
    transition: all 0.3s ease;
}
.navbar-toggler {
    border: none;
    outline: none;
}

.navbar-toggler:focus {
    box-shadow: none;
}
.nav-link:hover {
    background: rgba(255, 255, 255, 0.2);
    color: #fff !important;
    transform: translateY(-2px);
}
@keyframes swim {
    0%, 100% { transform: translateX(0); }
    50% { transform: translateX(6px); }
}

/* KONTEN UTAMA */
.container.main-content {
    flex: 1;
    background: rgba(255, 255, 255, 0.2); 
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(10px);
    
    width: 100%; 
    max-width: none; 
    margin: 0; 
    border-radius: 0; 
    padding: 2.5rem 3rem; 
    box-shadow: 0 20px 50px rgba(14, 165, 233, 0.2);
    border: none; 
    min-height: 100%; 
}


footer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    z-index: 1000; 
    background: linear-gradient(135deg, #0369a1 0%, #075985 100%);
    color: white;
    padding: 1rem 0; 
    box-shadow: 0 -4px 12px rgba(14, 165, 233, 0.2);
}

footer p {
    margin: 0;
    opacity: 0.9;
}

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top shadow-sm">
  <div class="container-fluid p-0">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo e(route('fishes.index')); ?>">
      <i></i>
      <span>FISHIT MANAGER</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end mt-2 mt-lg-0" id="navbarNav">
      <ul class="navbar-nav text-center">
        <li class="nav-item mb-2 mb-lg-0">
          <a class="nav-link active" href="<?php echo e(route('fishes.index')); ?>">
            <i class="fas fa-home me-1"></i> Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('fishes.create')); ?>">
            <i class="fas fa-plus-circle me-1"></i> Add New
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container main-content <?php echo $__env->yieldContent('extra-class'); ?>"> <?php if(session('success')): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> Please correct the errors below.
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>

<footer>
  <div class="container-custom"> <div class="text-center">
      <p>&copy; <?php echo e(date('Y')); ?> FishIt Manager. All rights reserved.</p>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Praktikum_8\resources\views/layouts/app.blade.php ENDPATH**/ ?>