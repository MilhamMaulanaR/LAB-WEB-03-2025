

<?php $__env->startSection('extra-class', 'transparent-mode'); ?>
<?php $__env->startSection('title', 'Edit Ikan'); ?>

<?php $__env->startSection('content'); ?>
<div class="fish-form-container mx-auto p-4">
    <h3 class="mb-4 text-center fw-bold text-primary">Edit Ikan</h3>

    <form action="<?php echo e(route('fishes.update', $fish)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Nama Ikan</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $fish->name)); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Rarity</label>
            <select name="rarity" class="form-select">
                <?php $__currentLoopData = $rarities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r); ?>" <?php echo e(old('rarity', $fish->rarity) == $r ? 'selected' : ''); ?>>
                        <?php echo e($r); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['rarity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Berat Minimum (kg)</label>
                <input type="number" step="0.01" name="base_weight_min" class="form-control"
                       min="0.1" max="100" value="<?php echo e(old('base_weight_min', $fish->base_weight_min)); ?>" required>
                <?php $__errorArgs = ['base_weight_min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label>Berat Maksimum (kg)</label>
                <input type="number" step="0.01" name="base_weight_max" class="form-control"
                       min="0.1" max="100" value="<?php echo e(old('base_weight_max', $fish->base_weight_max)); ?>" required>
                <?php $__errorArgs = ['base_weight_max'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="mb-3">
            <label>Harga Jual per Kg (Coins)</label>
            <input type="number" name="sell_price_per_kg" class="form-control"
                   value="<?php echo e(old('sell_price_per_kg', $fish->sell_price_per_kg)); ?>">
            <?php $__errorArgs = ['sell_price_per_kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Catch Probability (%)</label>
            <input type="number" step="0.01" name="catch_probability" class="form-control"
                   min="0.01" max="100" value="<?php echo e(old('catch_probability', $fish->catch_probability)); ?>" required>
            <?php $__errorArgs = ['catch_probability'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control" rows="4"><?php echo e(old('description', $fish->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="text-center mt-4">
            <button class="btn btn-primary px-4 me-2">Update</button>
            <a href="<?php echo e(route('fishes.index')); ?>" class="btn btn-outline-secondary px-4">Batal</a>
        </div>
    </form>
</div>

<style>
    body {
        background: url('<?php echo e(asset('image/bg.png')); ?>') center/cover no-repeat;
        font-family: "Poppins", sans-serif;
    }

    .transparent-mode {
        background: rgba(255,255,255,0.3);
        backdrop-filter: blur(10px);
    }

    .fish-form-container {
        max-width: 600px;
        background: rgba(255,255,255,0.35);
        backdrop-filter: blur(15px);
        padding: 2rem;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        margin: 60px auto;
        transition: 0.3s;
    }

    .fish-form-container:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }

    label {
        font-weight: 600;
        color: #0b3954;
    }

    input, textarea, select {
        border-radius: 10px;
        border: 1px solid rgba(0,0,0,0.1);
    }

    .btn-primary {
        background-color: #1e88e5;
        border: none;
        color: #fff;
    }
    .btn-primary:hover { background-color: #1565c0; }

    .btn-outline-secondary {
        background-color: rgba(255,255,255,0.3);
        border: 1px solid rgba(255,255,255,0.5);
        color: #0a3d62;
    }
    .btn-outline-secondary:hover { background-color: rgba(255,255,255,0.5); }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_8\resources\views/fishes/edit.blade.php ENDPATH**/ ?>