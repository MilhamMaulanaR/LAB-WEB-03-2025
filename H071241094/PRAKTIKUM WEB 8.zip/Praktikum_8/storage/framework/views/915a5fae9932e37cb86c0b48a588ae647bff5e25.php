

<?php $__env->startSection('title', 'Daftar Ikan'); ?>

<?php $__env->startSection('content'); ?>
<style>
    body {
        position: relative;
        min-height: 100vh;
        margin: 0;
        font-family: 'Poppins', sans-serif;
        color: #0b2948;
    }

    body::before {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background:
            linear-gradient(rgba(0, 80, 160, 0.3), rgba(180, 220, 255, 0.4)),
            url("<?php echo e(asset('image/bg.png')); ?>");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        z-index: -1;
        filter: brightness(0.97);
    }
    .card {
        background: rgba(255, 255, 255, 0.5);
        border: none;
        border-radius: 12px;
        box-shadow: 0 6px 20px rgba(0, 70, 150, 0.15);
    }
    form.row {
        background: linear-gradient(135deg, rgba(230, 245, 255, 0.95), rgba(200, 230, 255, 0.9));
        padding: 12px;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0, 80, 160, 0.15);
    }

    .btn-primary {
        background: linear-gradient(90deg, #1b6dc1, #3fa3f7);
        border: none;
        color: white;
        transition: 0.3s;
    }

    .btn-primary:hover {
        background: linear-gradient(90deg, #175d9f, #1b82d6);
        transform: scale(1.03);
    }

    .btn-secondary {
        background: #f3f8fc;
        border: 1px solid #c6d8f5;
        color: #0b2948;
    }

    .btn-info {
        background-color: #61b4ff;
        border: none;
        color: #fff;
    }

    .btn-warning {
        background-color: #ffe9a1;
        border: none;
        color: #4b3f00;
    }

    .btn-danger {
        background-color: #f28b82;
        border: none;
        color: white;
    }

    .table {
        border-radius: 10px;
        overflow: hidden;
    }

    thead.table-light {
        background: linear-gradient(90deg, #e4f1ff, #cbe2ff);
        color: #0b2948;
        font-weight: 600;
    }

    tbody tr:hover {
        background-color: rgba(220, 240, 255, 0.6);
        transition: background 0.3s;
    }

    @media (max-width: 768px) {
        .container {
            padding: 15px;
        }
        form.row {
            flex-direction: column;
        }
    }
</style>

<div class="container mt-4">

    <form method="GET" class="row g-2 mb-3 align-items-end">
        <!-- Search by name -->
        <div class="col-md-3">
            <input id="search" name="search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm" placeholder="Cari nama...">
        </div>

        <!-- Filter by rarity -->
        <div class="col-md-2">
            <select id="rarity" name="rarity" class="form-select form-select-sm">
                <?php $__currentLoopData = $rarities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(request('rarity') == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Sort by -->
        <div class="col-md-3">
            <select id="sort_by" name="sort_by" class="form-select form-select-sm">
                <option value="" <?php echo e(empty(request('sort_by')) ? 'selected' : ''); ?>>Urutkan berdasarkan</option>
                <option value="name" <?php echo e(request('sort_by') == 'name' ? 'selected' : ''); ?>>Nama</option>
                <option value="sell_price_per_kg" <?php echo e(request('sort_by') == 'sell_price_per_kg' ? 'selected' : ''); ?>>Harga</option>
                <option value="catch_probability" <?php echo e(request('sort_by') == 'catch_probability' ? 'selected' : ''); ?>>Peluang %</option>
            </select>
        </div>

        <!-- Sort direction -->
        <div class="col-md-2">
            <select id="sort_dir" name="sort_dir" class="form-select form-select-sm">
                <option value="desc" <?php echo e(request('sort_dir') == 'desc' ? 'selected' : ''); ?>>Menurun</option>
                <option value="asc" <?php echo e(request('sort_dir') == 'asc' ? 'selected' : ''); ?>>Menaik</option>
            </select>
        </div>

        <!-- Tombol -->
        <div class="col-md-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary btn-sm flex-grow-1">Terapkan</button>
            <a href="<?php echo e(route('fishes.index')); ?>" class="btn btn-secondary btn-sm flex-grow-1">Refresh</a>
        </div>
    </form>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Rarity</th>
                            <th>Berat (kg)</th>
                            <th>Harga /kg</th>
                            <th>Peluang %</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $fishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($fish->id); ?></td>
                                <td><?php echo e($fish->name); ?></td>
                                <td><?php echo e($fish->rarity); ?></td>
                                <td><?php echo e($fish->weight_range); ?></td>
                                <td><?php echo e($fish->formatted_price); ?></td>
                                <td><?php echo e(number_format($fish->catch_probability, 2)); ?>%</td>
                                <td>
                                    <a href="<?php echo e(route('fishes.show', $fish)); ?>" class="btn btn-sm btn-info">Lihat</a>
                                    <a href="<?php echo e(route('fishes.edit', $fish)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <form action="<?php echo e(route('fishes.destroy', $fish)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus ikan ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Tidak ada ikan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center mt-3">
        <?php echo e($fishes->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_8\resources\views/fishes/index.blade.php ENDPATH**/ ?>