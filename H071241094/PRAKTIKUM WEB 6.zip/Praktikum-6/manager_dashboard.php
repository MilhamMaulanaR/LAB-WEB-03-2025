<?php
session_start();
require 'koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'Project Manager') {
    die("Akses ditolak");
}

$manager_id = $_SESSION['user']['id'];

// =========================
// Hitung total proyek
// =========================
$sql = "SELECT COUNT(*) as total_proyek FROM projects WHERE manager_id=?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $manager_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$total_proyek = mysqli_fetch_assoc($result)['total_proyek'] ?? 0;

// =========================
// Hitung total tugas
// =========================
$sql = "SELECT COUNT(*) as total_tugas FROM tasks t
        JOIN projects p ON t.project_id = p.id
        WHERE p.manager_id=?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $manager_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$total_tugas = mysqli_fetch_assoc($result)['total_tugas'] ?? 0;

// =========================
// Hitung status tugas
// =========================
$status = ['belum' => 0, 'proses' => 0, 'selesai' => 0];

$sql = "SELECT status, COUNT(*) as jumlah 
        FROM tasks t 
        JOIN projects p ON t.project_id = p.id
        WHERE p.manager_id=? 
        GROUP BY status";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $manager_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($row = mysqli_fetch_assoc($result)) {
    $status[$row['status']] = $row['jumlah'];
}

// =========================
// Ambil daftar proyek
// =========================
$sql = "SELECT * FROM projects WHERE manager_id=?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $manager_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projects = [];
while ($p = mysqli_fetch_assoc($result)) {
    $projects[] = $p;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Project Manager</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen font-sans">

    <header class="bg-gradient-to-r from-green-600 to-green-600 text-white shadow-lg 
                   p-4 sm:p-6 flex flex-col sm:flex-row justify-between items-center gap-3">

        <h1 class="text-xl sm:text-2xl font-bold">Dashboard Project Manager</h1>

        <div class="flex flex-wrap gap-2 sm:gap-3">
           <a href="tambah_proyek.php"
   class="bg-white text-green-700 hover:bg-green-100 px-4 py-2 rounded-md font-semibold transition">
   Tambah Proyek
</a>

            <a href="logout.php"
   class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md font-semibold transition shadow-md">
   Logout
</a>

        </div>
    </header>

    <main class="p-4 sm:p-6 max-w-7xl mx-auto">

        <section class="mb-8">
            <h2 class="text-lg sm:text-xl font-semibold text-green-800 mb-4">Ringkasan</h2>


            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="bg-green-300 rounded-xl shadow p-5 text-center hover:shadow-lg transition">

                    <h3 class="text-green-700 font-medium">Jumlah Proyek</h3>
                    <p class="text-2xl font-bold text-gray-800"><?= $total_proyek ?></p>
                </div>

                <div class="bg-green-300 rounded-xl shadow p-5 text-center hover:shadow-lg transition">
                    <h3 class="text-green-700 font-medium">Jumlah Tugas</h3>
                    <p class="text-2xl font-bold text-gray-800"><?= $total_tugas ?></p>
                </div>

                <div class="bg-green-300 rounded-xl shadow p-5 text-center hover:shadow-lg transition">
                    <h3 class="text-green-700 font-medium">Status Tugas</h3>
                    <p class="text-sm text-gray-700">Belum: <?= $status['belum'] ?></p>
                    <p class="text-sm text-gray-700">Proses: <?= $status['proses'] ?></p>
                    <p class="text-sm text-gray-700">Selesai: <?= $status['selesai'] ?></p>
                </div>
            </div>
        </section>

        <section>
            <h2 class="text-lg sm:text-xl font-semibold text-green-800 mb-4">Daftar Proyek</h2>

            <?php if (count($projects) === 0): ?>
                <p class="text-gray-600">Belum ada proyek.</p>
            <?php else: ?>
                <div class="overflow-x-auto bg-white rounded-xl shadow">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
   <thead class="bg-green-600 text-white">
    <tr>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">
            Nama Proyek
        </th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">
            Deskripsi
        </th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">
            Tanggal Mulai
        </th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">
            Tanggal Selesai
        </th>
        <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">
            Aksi
        </th>
    </tr>


                        </thead>

                        <tbody class="divide-y divide-green-200">
    <?php foreach ($projects as $p): ?>
        <tr class="hover:bg-green-50 transition">
            <td class="px-4 py-3 text-green-900 font-medium">
                <?= htmlspecialchars($p['nama_proyek']) ?>
            </td>
            <td class="px-4 py-3 text-green-800">
                <?= htmlspecialchars($p['deskripsi']) ?>
            </td>
            <td class="px-4 py-3 text-green-800">
                <?= htmlspecialchars($p['tanggal_mulai']) ?>
            </td>
            <td class="px-4 py-3 text-green-800">
                <?= htmlspecialchars($p['tanggal_selesai']) ?>
            </td>
            <td class="px-4 py-3 whitespace-nowrap flex flex-wrap gap-2">
                <a href="edit_proyek.php?id=<?= $p['id'] ?>"
                   class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded-md transition shadow-sm">
                   Edit
                </a>
                <a href="hapus_proyek.php?id=<?= $p['id'] ?>"
                   onclick="return confirm('Yakin ingin menghapus proyek ini?')"
                   class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md transition shadow-sm">
                   Hapus
                </a>
                <a href="tugas_crud.php?project_id=<?= $p['id'] ?>"
                   class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md transition shadow-sm">
                   Tugas
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
</tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

    </main>
</body>
</html>
